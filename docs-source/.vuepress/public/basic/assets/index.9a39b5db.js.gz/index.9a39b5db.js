
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{r as e,b as a,c as t,t as s,j as l,G as i,g as o,h as n,F as r,H as p,E as c}from"./index.eaca9d64.js";/* empty css                */import{_ as d}from"./index.8eb858d1.js";import{_ as u}from"./plugin-vue_export-helper.21dcd24c.js";const v={key:0,class:"title-container"};var f=u({name:"index",props:{title:{type:String,default:""},collaspe:{type:Boolean,default:!1},height:{type:String,default:""}},setup(u){const f=e(u.collaspe);function m(){f.value=!1}return(e,g)=>{const h=d,_=c;return a(),t("div",{class:r({"page-main":!0,"is-collaspe":f.value}),style:p({height:f.value?u.height:""})},[u.title?(a(),t("div",v,s(u.title),1)):l("v-if",!0),i(e.$slots,"default",{},void 0,!0),f.value?(a(),t("div",{key:1,class:"collaspe",title:"展开",onClick:m},[o(_,null,{default:n((()=>[o(h,{name:"ep:arrow-down"})])),_:1})])):l("v-if",!0)],6)}}},[["__scopeId","data-v-6bb431dc"]]);export{f as _};
