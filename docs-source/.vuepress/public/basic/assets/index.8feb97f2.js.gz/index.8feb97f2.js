
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{E as e,b as t,c as n,g as a,h as o,e as r,s}from"./index.eaca9d64.js";import{E as i}from"./el-button.3a9a3385.js";/* empty css                */import{_ as l}from"./index.8eb858d1.js";import{_ as d}from"./index.34688040.js";import{_ as p}from"./plugin-vue_export-helper.21dcd24c.js";import"./index2.fa9449b9.js";import"./index2.200c9b4b.js";const m={},u=r("p",null,"提供两块插槽：",-1),c=r("p",null,"一块是 content 区域插槽，一块是右侧区域",-1),f=s(" 返回 ");var b=p(m,[["render",function(r,s){const p=d,m=l,b=e,j=i;return t(),n("div",null,[a(p,{title:"页头",content:"PageHeader"}),a(p,{title:"页面标题"},{content:o((()=>[u,c])),default:o((()=>[a(j,{round:""},{icon:o((()=>[a(b,null,{default:o((()=>[a(m,{name:"ep:arrow-left"})])),_:1})])),default:o((()=>[f])),_:1})])),_:1})])}]]);export{b as default};
