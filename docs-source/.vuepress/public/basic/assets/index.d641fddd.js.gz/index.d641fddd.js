
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{E as e,c as t,e as n,f as o,m as r,b as a,s}from"./index.1b2a4798.js";import{E as i}from"./el-button.a29297df.js";/* empty css                */import{_ as l}from"./index.373c9150.js";import{_ as d}from"./index.3420411b.js";import{_ as f}from"./plugin-vue_export-helper.21dcd24c.js";import"./index.c8167427.js";import"./index.48ef7773.js";const m={},p=a("p",null,"提供两块插槽：",-1),u=a("p",null,"一块是 content 区域插槽，一块是右侧区域",-1),c=s(" 返回 ");var j=f(m,[["render",function(a,s){const f=d,m=l,j=e,x=i;return r(),t("div",null,[n(f,{title:"页头",content:"PageHeader"}),n(f,{title:"页面标题"},{content:o((()=>[p,u])),default:o((()=>[n(x,{round:""},{icon:o((()=>[n(j,null,{default:o((()=>[n(m,{name:"ep:arrow-left"})])),_:1})])),default:o((()=>[c])),_:1})])),_:1})])}]]);export{j as default};
