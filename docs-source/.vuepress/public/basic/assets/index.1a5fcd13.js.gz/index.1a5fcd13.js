
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.4d88f6c2.js";import{c as l,e as a,f as o,m as t}from"./index.1b2a4798.js";import{E as d}from"./el-switch.36016b8f.js";import{_ as i}from"./index.c78ef260.js";import{_ as u}from"./plugin-vue_export-helper.21dcd24c.js";/* empty css                */import"./index.373c9150.js";import"./validator.659ac956.js";import"./event.75bf56a9.js";import"./index.48ef7773.js";import"./index.c8167427.js";import"./error.b438369f.js";import"./el-alert.bb5b0746.js";var m=u({data:()=>({value:!0,value1:!0,value2:!0,value3:!1})},[["render",function(u,m,r,s,n,c){const p=i,v=d,f=e;return t(),l("div",null,[a(p),a(f,{title:"基础用法",class:"demo"},{default:o((()=>[a(v,{modelValue:n.value,"onUpdate:modelValue":m[0]||(m[0]=e=>n.value=e),"active-color":"#13ce66","inactive-color":"#ff4949"},null,8,["modelValue"])])),_:1}),a(f,{title:"文字描述",class:"demo"},{default:o((()=>[a(v,{modelValue:n.value1,"onUpdate:modelValue":m[1]||(m[1]=e=>n.value1=e),"active-text":"按月付费","inactive-text":"按年付费"},null,8,["modelValue"])])),_:1}),a(f,{title:"禁用状态",class:"demo"},{default:o((()=>[a(v,{modelValue:n.value2,"onUpdate:modelValue":m[2]||(m[2]=e=>n.value2=e),disabled:"",style:{"margin-right":"10px"}},null,8,["modelValue"]),a(v,{modelValue:n.value3,"onUpdate:modelValue":m[3]||(m[3]=e=>n.value3=e),disabled:""},null,8,["modelValue"])])),_:1})])}]]);export{m as default};
