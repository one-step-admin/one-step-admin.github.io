
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.3db21fe3.js";import{_ as t}from"./index.7d2f4006.js";import{_ as s}from"./logo.d77fe55e.js";import{_ as i}from"./plugin-vue_export-helper.21dcd24c.js";import{c as l,e as n,f as a,m as o,s as r,b as d}from"./index.cc1bbbc5.js";/* empty css                */import"./index.236d052b.js";const f={},m=r(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),p=r(" 这里放页面内容 "),c=d("h1",null,"One-step-admin",-1),u=d("img",{src:s},null,-1),b=d("p",null,"这是一款干啥都快人一步的中后台框架，它拥有全新的交互方式，只为提升操作效率而生。",-1);var _=i(f,[["render",function(s,i){const r=t,d=e;return o(),l("div",null,[n(r,{title:"内容块",content:"PageMain"}),n(d,null,{default:a((()=>[m])),_:1}),n(d,{title:"你可以设置一个自定义的标题"},{default:a((()=>[p])),_:1}),n(d,{title:"带展开功能",collaspe:"",height:"200px"},{default:a((()=>[c,u,b])),_:1})])}]]);export{_ as default};
