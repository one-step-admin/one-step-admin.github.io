
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as m}from"./index.ea3b2f3a.js";import{_ as r}from"./index.8c6513b1.js";import{_ as d}from"./plugin-vue_export-helper.21dcd24c.js";import{C as i,f as o,e as a,r as p,o as _}from"./vendor.7ac17c5d.js";const c={data(){return{value:!0,value1:!0,value2:!0,value3:!1}}};function v(f,e,V,x,l,g){const s=r,n=p("el-switch"),u=m;return _(),i("div",null,[o(s),o(u,{title:"\u57FA\u7840\u7528\u6CD5",class:"demo"},{default:a(()=>[o(n,{modelValue:l.value,"onUpdate:modelValue":e[0]||(e[0]=t=>l.value=t),"active-color":"#13ce66","inactive-color":"#ff4949"},null,8,["modelValue"])]),_:1}),o(u,{title:"\u6587\u5B57\u63CF\u8FF0",class:"demo"},{default:a(()=>[o(n,{modelValue:l.value1,"onUpdate:modelValue":e[1]||(e[1]=t=>l.value1=t),"active-text":"\u6309\u6708\u4ED8\u8D39","inactive-text":"\u6309\u5E74\u4ED8\u8D39"},null,8,["modelValue"])]),_:1}),o(u,{title:"\u7981\u7528\u72B6\u6001",class:"demo"},{default:a(()=>[o(n,{modelValue:l.value2,"onUpdate:modelValue":e[2]||(e[2]=t=>l.value2=t),disabled:"",style:{"margin-right":"10px"}},null,8,["modelValue"]),o(n,{modelValue:l.value3,"onUpdate:modelValue":e[3]||(e[3]=t=>l.value3=t),disabled:""},null,8,["modelValue"])]),_:1})])}var w=d(c,[["render",v]]);export{w as default};
