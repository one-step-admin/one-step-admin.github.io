
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
var e=Object.defineProperty,t=Object.defineProperties,r=Object.getOwnPropertyDescriptors,s=Object.getOwnPropertySymbols,a=Object.prototype.hasOwnProperty,o=Object.prototype.propertyIsEnumerable,i=(t,r,s)=>r in t?e(t,r,{enumerable:!0,configurable:!0,writable:!0,value:s}):t[r]=s;import{A as n,B as l,d as c,C as p,D as d,b as y,c as u,F as f,f as v,G as b,j as g,H as h,_ as m,I as j,u as O,s as _,t as w}from"./index.eaca9d64.js";import{_ as P}from"./plugin-vue_export-helper.21dcd24c.js";const k=n({direction:{type:String,values:["horizontal","vertical"],default:"horizontal"},contentPosition:{type:String,values:["left","center","right"],default:"center"},borderStyle:{type:l(String),default:"solid"}}),S=c((x=((e,t)=>{for(var r in t||(t={}))a.call(t,r)&&i(e,r,t[r]);if(s)for(var r of s(t))o.call(t,r)&&i(e,r,t[r]);return e})({},{name:"ElDivider"}),t(x,r({props:k,setup(e){const t=e,r=p("divider"),s=d((()=>r.cssVar({"border-style":t.borderStyle})));return(e,t)=>(y(),u("div",{class:f([v(r).b(),v(r).m(e.direction)]),style:h(v(s)),role:"separator"},[e.$slots.default&&"vertical"!==e.direction?(y(),u("div",{key:0,class:f([v(r).e("text"),v(r).is(e.contentPosition)])},[b(e.$slots,"default")],2)):g("v-if",!0)],6))}}))));var x;const D=j(m(S,[["__file","/home/runner/work/element-plus/element-plus/packages/components/divider/src/divider.vue"]]));const E={class:"copyright"},I=["href"],z={key:1},A=_(" All Rights Reserved ");var C=P({name:"index",setup(e){const t=O();return(e,r)=>(y(),u("footer",E,[_(" Copyright © "+w(v(t).copyright.dates)+" ",1),v(t).copyright.website?(y(),u("a",{key:0,href:v(t).copyright.website,target:"_blank",rel:"noopener"},w(v(t).copyright.company)+",",9,I)):(y(),u("span",z,w(v(t).copyright.company)+",",1)),A]))}},[["__scopeId","data-v-2a579a08"]]);export{D as E,C as _};
