
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.f6f9a61b.js";import{_ as l}from"./index.2283cd0c.js";import{_ as a}from"./plugin-vue_export-helper.21dcd24c.js";import{C as o,f as u,e as t,r as d,o as s}from"./vendor.2ae12b47.js";var r=a({data:()=>({value1:null,value2:null,value3:3.7})},[["render",function(a,r,m,n,f,v){const i=l,c=d("el-rate"),p=e;return s(),o("div",null,[u(i),u(p,{title:"基础用法",class:"demo"},{default:t((()=>[u(c,{modelValue:f.value1,"onUpdate:modelValue":r[0]||(r[0]=e=>f.value1=e)},null,8,["modelValue"])])),_:1}),u(p,{title:"辅助文字",class:"demo"},{default:t((()=>[u(c,{modelValue:f.value2,"onUpdate:modelValue":r[1]||(r[1]=e=>f.value2=e),"show-text":"",texts:["极差","差","一般","好","极好"]},null,8,["modelValue"])])),_:1}),u(p,{title:"只读",class:"demo"},{default:t((()=>[u(c,{modelValue:f.value3,"onUpdate:modelValue":r[2]||(r[2]=e=>f.value3=e),disabled:"","show-score":"","text-color":"#ff9900","score-template":"{value}"},null,8,["modelValue"])])),_:1})])}]]);export{r as default};
