
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.4d88f6c2.js";import{c as l,e as m,f as o,m as a}from"./index.1b2a4798.js";import{E as t}from"./el-input-number.eccc2b30.js";import"./el-input.2b6dddff.js";import{_ as d}from"./index.c78ef260.js";import{_ as n}from"./plugin-vue_export-helper.21dcd24c.js";/* empty css                */import"./index.373c9150.js";import"./index.2b8a8e6d.js";import"./event.561dcd8a.js";import"./index.48ef7773.js";import"./index.c8167427.js";import"./error.b438369f.js";import"./arrow-up.997ff15e.js";import"./arrow-down.dc7b2b25.js";import"./plus.c100d8a3.js";import"./typescript.b0ac2d0c.js";import"./event.75bf56a9.js";import"./index.ab0ffd8a.js";import"./isNil.aac33454.js";import"./el-alert.bb5b0746.js";var i=n({data:()=>({num:1,num2:1,num3:5,num4:1,num5:1})},[["render",function(n,i,s,u,r,p){const c=d,f=t,j=e;return a(),l("div",null,[m(c),m(j,{title:"基础用法",class:"demo"},{default:o((()=>[m(f,{modelValue:r.num,"onUpdate:modelValue":i[0]||(i[0]=e=>r.num=e),min:1,max:10,label:"描述文字"},null,8,["modelValue"])])),_:1}),m(j,{title:"禁用状态",class:"demo"},{default:o((()=>[m(f,{modelValue:r.num2,"onUpdate:modelValue":i[1]||(i[1]=e=>r.num2=e),disabled:!0},null,8,["modelValue"])])),_:1}),m(j,{title:"步数",class:"demo"},{default:o((()=>[m(f,{modelValue:r.num3,"onUpdate:modelValue":i[2]||(i[2]=e=>r.num3=e),step:2},null,8,["modelValue"])])),_:1}),m(j,{title:"精度",class:"demo"},{default:o((()=>[m(f,{modelValue:r.num4,"onUpdate:modelValue":i[3]||(i[3]=e=>r.num4=e),precision:2,step:.1,max:10},null,8,["modelValue","step"])])),_:1}),m(j,{title:"按钮位置",class:"demo"},{default:o((()=>[m(f,{modelValue:r.num5,"onUpdate:modelValue":i[4]||(i[4]=e=>r.num5=e),"controls-position":"right",min:1,max:10},null,8,["modelValue"])])),_:1})])}]]);export{i as default};
