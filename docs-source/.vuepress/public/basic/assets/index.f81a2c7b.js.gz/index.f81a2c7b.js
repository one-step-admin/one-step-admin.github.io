
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.4d88f6c2.js";import{_ as t}from"./index.3420411b.js";import{_ as s}from"./logo.d77fe55e.js";import{_ as a}from"./plugin-vue_export-helper.21dcd24c.js";import{c as i,e as l,f as n,m as o,s as r,b as d}from"./index.1b2a4798.js";/* empty css                */import"./index.373c9150.js";const m={},p=r(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),f=r(" 这里放页面内容 "),u=d("h1",null,"One-step-admin",-1),c=d("img",{src:s},null,-1),_=d("p",null,"这是一款干啥都快人一步的中后台框架，它拥有全新的交互方式，只为提升操作效率而生。",-1);var j=a(m,[["render",function(s,a){const r=t,d=e;return o(),i("div",null,[l(r,{title:"内容块",content:"PageMain"}),l(d,null,{default:n((()=>[p])),_:1}),l(d,{title:"你可以设置一个自定义的标题"},{default:n((()=>[f])),_:1}),l(d,{title:"带展开功能",collaspe:"",height:"200px"},{default:n((()=>[u,c,_])),_:1})])}]]);export{j as default};
