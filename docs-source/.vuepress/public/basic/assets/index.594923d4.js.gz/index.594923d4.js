
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.3cef4ded.js";import{_ as t}from"./index.f2802abe.js";import{_ as a}from"./logo.d77fe55e.js";import{_ as l}from"./plugin-vue_export-helper.21dcd24c.js";import{c as n,e as s,f as i,n as o,x as r,b as d}from"./index.6885a104.js";const f={},p=r(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),u=r(" 这里放页面内容 "),m=d("h1",null,"One-step-admin",-1),c=d("img",{src:a},null,-1),_=d("p",null,"这是一款干啥都快人一步的中后台框架，它拥有全新的交互方式，只为提升操作效率而生。",-1);var x=l(f,[["render",function(a,l){const r=t,d=e;return o(),n("div",null,[s(r,{title:"内容块",content:"PageMain"}),s(d,null,{default:i((()=>[p])),_:1}),s(d,{title:"你可以设置一个自定义的标题"},{default:i((()=>[u])),_:1}),s(d,{title:"带展开功能",collaspe:"",height:"200px"},{default:i((()=>[m,c,_])),_:1})])}]]);export{x as default};
