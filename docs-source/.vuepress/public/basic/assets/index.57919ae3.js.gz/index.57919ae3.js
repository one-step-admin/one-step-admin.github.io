
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.9a39b5db.js";import{b as l,c as m,g as o,h as a}from"./index.eaca9d64.js";import{E as t}from"./el-input-number.f135ee3a.js";import"./el-input.0d3e4369.js";import{_ as i}from"./index.68f42353.js";import{_ as n}from"./plugin-vue_export-helper.21dcd24c.js";/* empty css                */import"./index.8eb858d1.js";import"./isNil.aac33454.js";import"./index2.7854a381.js";import"./event2.622b6e35.js";import"./index2.a801f47d.js";import"./index2.200c9b4b.js";import"./index2.fa9449b9.js";import"./error2.8f448c70.js";import"./arrow-up.e399cba9.js";import"./arrow-down.2b67fccc.js";import"./plus.25effb87.js";import"./typescript2.50fc0493.js";import"./event2.aca9aa52.js";import"./index2.8e851031.js";import"./el-alert.14161a0c.js";import"./el-link.9eeb3744.js";var d=n({data:()=>({num:1,num2:1,num3:5,num4:1,num5:1})},[["render",function(n,d,s,u,r,p){const c=i,j=t,f=e;return l(),m("div",null,[o(c),o(f,{title:"基础用法",class:"demo"},{default:a((()=>[o(j,{modelValue:r.num,"onUpdate:modelValue":d[0]||(d[0]=e=>r.num=e),min:1,max:10,label:"描述文字"},null,8,["modelValue"])])),_:1}),o(f,{title:"禁用状态",class:"demo"},{default:a((()=>[o(j,{modelValue:r.num2,"onUpdate:modelValue":d[1]||(d[1]=e=>r.num2=e),disabled:!0},null,8,["modelValue"])])),_:1}),o(f,{title:"步数",class:"demo"},{default:a((()=>[o(j,{modelValue:r.num3,"onUpdate:modelValue":d[2]||(d[2]=e=>r.num3=e),step:2},null,8,["modelValue"])])),_:1}),o(f,{title:"精度",class:"demo"},{default:a((()=>[o(j,{modelValue:r.num4,"onUpdate:modelValue":d[3]||(d[3]=e=>r.num4=e),precision:2,step:.1,max:10},null,8,["modelValue","step"])])),_:1}),o(f,{title:"按钮位置",class:"demo"},{default:a((()=>[o(j,{modelValue:r.num5,"onUpdate:modelValue":d[4]||(d[4]=e=>r.num5=e),"controls-position":"right",min:1,max:10},null,8,["modelValue"])])),_:1})])}]]);export{d as default};
