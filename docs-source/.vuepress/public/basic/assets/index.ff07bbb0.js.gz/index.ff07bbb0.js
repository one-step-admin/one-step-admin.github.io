
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.9a39b5db.js";import{b as l,c as a,g as o,h as t}from"./index.eaca9d64.js";import{E as d}from"./el-switch.e6b825a5.js";import{_ as i}from"./index.68f42353.js";import{_ as u}from"./plugin-vue_export-helper.21dcd24c.js";/* empty css                */import"./index.8eb858d1.js";import"./validator2.1a757222.js";import"./event2.aca9aa52.js";import"./index2.200c9b4b.js";import"./index2.fa9449b9.js";import"./error2.8f448c70.js";import"./el-alert.14161a0c.js";import"./el-link.9eeb3744.js";var r=u({data:()=>({value:!0,value1:!0,value2:!0,value3:!1})},[["render",function(u,r,m,s,n,p){const c=i,v=d,f=e;return l(),a("div",null,[o(c),o(f,{title:"基础用法",class:"demo"},{default:t((()=>[o(v,{modelValue:n.value,"onUpdate:modelValue":r[0]||(r[0]=e=>n.value=e),"active-color":"#13ce66","inactive-color":"#ff4949"},null,8,["modelValue"])])),_:1}),o(f,{title:"文字描述",class:"demo"},{default:t((()=>[o(v,{modelValue:n.value1,"onUpdate:modelValue":r[1]||(r[1]=e=>n.value1=e),"active-text":"按月付费","inactive-text":"按年付费"},null,8,["modelValue"])])),_:1}),o(f,{title:"禁用状态",class:"demo"},{default:t((()=>[o(v,{modelValue:n.value2,"onUpdate:modelValue":r[2]||(r[2]=e=>n.value2=e),disabled:"",style:{"margin-right":"10px"}},null,8,["modelValue"]),o(v,{modelValue:n.value3,"onUpdate:modelValue":r[3]||(r[3]=e=>n.value3=e),disabled:""},null,8,["modelValue"])])),_:1})])}]]);export{r as default};
