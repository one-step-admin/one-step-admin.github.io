
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.9a39b5db.js";import{_ as t}from"./index.34688040.js";import{_ as a}from"./logo.d77fe55e.js";import{_ as s}from"./plugin-vue_export-helper.21dcd24c.js";import{b as i,c as l,g as n,h as o,s as r,e as d}from"./index.eaca9d64.js";/* empty css                */import"./index.8eb858d1.js";const p={},m=r(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),u=r(" 这里放页面内容 "),f=d("h1",null,"One-step-admin",-1),c=d("img",{src:a},null,-1),_=d("p",null,"这是一款干啥都快人一步的中后台框架，它拥有全新的交互方式，只为提升操作效率而生。",-1);var g=s(p,[["render",function(a,s){const r=t,d=e;return i(),l("div",null,[n(r,{title:"内容块",content:"PageMain"}),n(d,null,{default:o((()=>[m])),_:1}),n(d,{title:"你可以设置一个自定义的标题"},{default:o((()=>[u])),_:1}),n(d,{title:"带展开功能",collaspe:"",height:"200px"},{default:o((()=>[f,c,_])),_:1})])}]]);export{g as default};
