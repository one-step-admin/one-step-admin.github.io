
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.d9ff6232.js";import{_ as t}from"./index.0582e115.js";import{_ as s}from"./logo.d77fe55e.js";import{_ as a}from"./plugin-vue_export-helper.21dcd24c.js";import{c as i,e as l,f as n,m as o,s as r,b as f}from"./index.2721a539.js";/* empty css                */import"./index.4b9f4b82.js";const d={},m=r(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),p=r(" 这里放页面内容 "),u=f("h1",null,"One-step-admin",-1),c=f("img",{src:s},null,-1),_=f("p",null,"这是一款干啥都快人一步的中后台框架，它拥有全新的交互方式，只为提升操作效率而生。",-1);var j=a(d,[["render",function(s,a){const r=t,f=e;return o(),i("div",null,[l(r,{title:"内容块",content:"PageMain"}),l(f,null,{default:n((()=>[m])),_:1}),l(f,{title:"你可以设置一个自定义的标题"},{default:n((()=>[p])),_:1}),l(f,{title:"带展开功能",collaspe:"",height:"200px"},{default:n((()=>[u,c,_])),_:1})])}]]);export{j as default};
