
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{E as e,c as t,e as a,f as l,m as d,s}from"./index.1b2a4798.js";/* empty css                */import{_ as f}from"./index.373c9150.js";import{_ as i}from"./index.4d88f6c2.js";import{E as u,_ as r}from"./index.c78ef260.js";import{_ as n}from"./plugin-vue_export-helper.21dcd24c.js";import"./el-alert.bb5b0746.js";const _={},o=s("默认链接"),p=s("主要链接"),c=s("成功链接"),m=s("警告链接"),b=s("危险链接"),y=s("信息链接"),g=s("默认链接"),j=s("主要链接"),x=s("成功链接"),v=s("警告链接"),h=s("危险链接"),w=s("信息链接"),E=s("无下划线"),k=s("有下划线"),I=s(" 编辑 "),q=s(" 查看 ");var z=n(_,[["render",function(s,n){const _=r,z=u,A=i,B=f,C=e;return d(),t("div",null,[a(_),a(A,{title:"基础用法",class:"demo"},{default:l((()=>[a(z,{href:"https://element.eleme.io",target:"_blank"},{default:l((()=>[o])),_:1}),a(z,{type:"primary"},{default:l((()=>[p])),_:1}),a(z,{type:"success"},{default:l((()=>[c])),_:1}),a(z,{type:"warning"},{default:l((()=>[m])),_:1}),a(z,{type:"danger"},{default:l((()=>[b])),_:1}),a(z,{type:"info"},{default:l((()=>[y])),_:1})])),_:1}),a(A,{title:"禁用状态",class:"demo"},{default:l((()=>[a(z,{disabled:""},{default:l((()=>[g])),_:1}),a(z,{type:"primary",disabled:""},{default:l((()=>[j])),_:1}),a(z,{type:"success",disabled:""},{default:l((()=>[x])),_:1}),a(z,{type:"warning",disabled:""},{default:l((()=>[v])),_:1}),a(z,{type:"danger",disabled:""},{default:l((()=>[h])),_:1}),a(z,{type:"info",disabled:""},{default:l((()=>[w])),_:1})])),_:1}),a(A,{title:"下划线",class:"demo"},{default:l((()=>[a(z,{underline:!1},{default:l((()=>[E])),_:1}),a(z,null,{default:l((()=>[k])),_:1})])),_:1}),a(A,{title:"图标",class:"demo"},{default:l((()=>[a(z,null,{default:l((()=>[a(C,{class:"el-icon--left"},{default:l((()=>[a(B,{name:"ep:edit"})])),_:1}),I])),_:1}),a(z,null,{default:l((()=>[q,a(C,{class:"el-icon--right"},{default:l((()=>[a(B,{name:"ep:view"})])),_:1})])),_:1})])),_:1})])}],["__scopeId","data-v-484ff390"]]);export{z as default};
