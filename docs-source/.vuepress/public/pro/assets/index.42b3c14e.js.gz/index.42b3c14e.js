
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e,bP as a,E as t,c as s,b as l,w as i,n,G as o,F as r,f as p,y as d}from"./index.0a5e3bc2.js";import"./el-tooltip.586473e3.js";import{E as f}from"./el-popper.807071fe.js";import{_ as m}from"./index.15becada.js";import{E as c}from"./el-button.2fada245.js";/* empty css                */import{_ as u}from"./index.5fef9d7d.js";import{_ as j}from"./index.872bc773.js";import"./index2.f37a6952.js";import"./focus-trap2.8b38c312.js";import"./event2.3b438cf1.js";import"./index2.fa2fe4ab.js";import"./index2.2a4e9295.js";import"./el-alert.2d5c6d9e.js";import"./el-link.080e9c24.js";const _=d(" 搜索 ");var b=e({setup(e){const d=a.filter((e=>"ep"===e.prefix))[0];return(e,a)=>{const b=j,x=u,v=t,y=c,k=m,E=f;return n(),s("div",null,[l(b),l(k,{class:"demo"},{default:i((()=>[l(v,null,{default:i((()=>[l(x,{name:"i-ep:edit"})])),_:1}),l(v,null,{default:i((()=>[l(x,{name:"i-ep:share"})])),_:1}),l(v,null,{default:i((()=>[l(x,{name:"i-ep:delete"})])),_:1}),l(y,{type:"primary"},{icon:i((()=>[l(v,null,{default:i((()=>[l(x,{name:"ep:search"})])),_:1})])),default:i((()=>[_])),_:1})])),_:1}),l(k,{title:"图标集合"},{default:i((()=>[(n(!0),s(o,null,r(p(d).icons,((e,a)=>(n(),s("div",{key:a,class:"list-icon"},[l(E,{class:"item",effect:"dark",content:`ep:${e}`,placement:"top"},{default:i((()=>[l(v,null,{default:i((()=>[l(x,{name:`ep:${e}`},null,8,["name"])])),_:2},1024)])),_:2},1032,["content"])])))),128))])),_:1})])}}},[["__scopeId","data-v-057dab35"]]);export{b as default};
