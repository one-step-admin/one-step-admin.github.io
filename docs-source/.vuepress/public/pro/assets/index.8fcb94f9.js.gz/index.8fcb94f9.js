
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a,u as e,n as s,c as o,y as t,t as n,g as r,B as d,C as l,m as p,h as c,w as i,b as u,D as f,F as m,E as y,i as g,A as h}from"./index.25647206.js";const b={class:"copyright"},_=["href"],v={key:1},w=t(" All Rights Reserved ");var k=a({setup(a){const d=e();return(a,e)=>(s(),o("footer",b,[t(" Copyright © "+n(r(d).copyright.dates)+" ",1),r(d).copyright.website?(s(),o("a",{key:0,href:r(d).copyright.website,target:"_blank",rel:"noopener"},n(r(d).copyright.company)+",",9,_)):(s(),o("span",v,n(r(d).copyright.company)+",",1)),w]))}},[["__scopeId","data-v-7586fb9c"]]);var x=a({setup(a){const{proxy:b}=h(),_=e(),v=d((()=>l()));function w(a){b.$i18n.locale=a,_.setDefaultLang(a)}return(a,e)=>{const d=p("el-dropdown-item"),l=p("el-dropdown-menu"),h=p("el-dropdown");return r(_).topbar.enableI18n?(s(),c(h,{key:0,class:"language-container",size:"default",onCommand:w},{dropdown:i((()=>[u(l,null,{default:i((()=>[(s(!0),o(m,null,f(r(v),((a,e)=>(s(),c(d,{key:e,disabled:r(_).app.defaultLang===a.name,command:a.name},{default:i((()=>[t(n(a.labelName),1)])),_:2},1032,["disabled","command"])))),128))])),_:1})])),default:i((()=>[y(a.$slots,"default",{},void 0,!0)])),_:3})):g("v-if",!0)}}},[["__scopeId","data-v-5d35ff72"]]);export{x as _,k as a};
