
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.e4264495.js";import{_ as l,c as a,g as o,w as t,o as d}from"./index.b046d3e8.js";import{E as i}from"./el-switch.ee336242.js";import{_ as u}from"./index.1af425e5.js";/* empty css                */import"./validator.b6b6feae.js";import"./event.e7ca8317.js";import"./index.16ef6f7e.js";import"./index.2b0c4341.js";import"./error.76088f19.js";import"./el-alert.026aaf76.js";import"./el-link.8c6cc258.js";var m=l({data:()=>({value:!0,value1:!0,value2:!0,value3:!1})},[["render",function(l,m,s,r,n,c){const v=u,f=i,p=e;return d(),a("div",null,[o(v),o(p,{title:"基础用法",class:"demo"},{default:t((()=>[o(f,{modelValue:n.value,"onUpdate:modelValue":m[0]||(m[0]=e=>n.value=e),"active-color":"#13ce66","inactive-color":"#ff4949"},null,8,["modelValue"])])),_:1}),o(p,{title:"文字描述",class:"demo"},{default:t((()=>[o(f,{modelValue:n.value1,"onUpdate:modelValue":m[1]||(m[1]=e=>n.value1=e),"active-text":"按月付费","inactive-text":"按年付费"},null,8,["modelValue"])])),_:1}),o(p,{title:"禁用状态",class:"demo"},{default:t((()=>[o(f,{modelValue:n.value2,"onUpdate:modelValue":m[2]||(m[2]=e=>n.value2=e),disabled:"",style:{"margin-right":"10px"}},null,8,["modelValue"]),o(f,{modelValue:n.value3,"onUpdate:modelValue":m[3]||(m[3]=e=>n.value3=e),disabled:""},null,8,["modelValue"])])),_:1})])}]]);export{m as default};
