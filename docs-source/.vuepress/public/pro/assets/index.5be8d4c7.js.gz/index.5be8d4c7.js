
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as t}from"./index.9c1fa942.js";import{bY as e,c as s,e as n,w as a,n as i,f as o,t as d,h as r,y as c}from"./index.05e4ed9f.js";import{E as f}from"./el-button.a01942a9.js";import{_ as l}from"./index.abd93cee.js";/* empty css                */import"./index.dd2c42e8.js";import"./index.48c8fc0e.js";import"./index.aa8c6f3e.js";const u=c("切换"),m=c("清空"),x={setup(c){const x=e();function p(){x.setText("热门"==x.text?"促销":"热门")}function j(){x.setText()}return(e,c)=>{const b=l,_=f,k=t;return i(),s("div",null,[n(b,{title:"文字标记",content:"搭配 Pinia 可实现动态设置。请控制文字展示长度，避免导航标记覆盖导航标题"}),n(k,null,{default:a((()=>[o("div",null,"当前 badge 值：'"+d(r(x).text)+"'",1),n(_,{onClick:p},{default:a((()=>[u])),_:1}),n(_,{onClick:j},{default:a((()=>[m])),_:1})])),_:1})])}}};export{x as default};
