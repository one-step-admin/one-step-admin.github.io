
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.7ae327c0.js";import{_ as l,c as a,g as m,w as o,o as t}from"./index.89c4a536.js";import{E as d}from"./el-input-number.7d3582fa.js";import"./el-input.344ef3e5.js";import{_ as n}from"./index.bca90ab2.js";/* empty css                */import"./index.71e1be7e.js";import"./event.e842ba5a.js";import"./index.a744c982.js";import"./index.0dfe2aba.js";import"./error.67356979.js";import"./arrow-up.62d5044f.js";import"./arrow-down.b0d54151.js";import"./plus.ce794555.js";import"./typescript.f55dff19.js";import"./event.87cd92d6.js";import"./index.4b6badd5.js";import"./isNil.aac33454.js";import"./el-alert.5b00153b.js";import"./el-link.2134bbaa.js";var s=l({data:()=>({num:1,num2:1,num3:5,num4:1,num5:1})},[["render",function(l,s,i,u,r,p){const j=n,c=d,f=e;return t(),a("div",null,[m(j),m(f,{title:"基础用法",class:"demo"},{default:o((()=>[m(c,{modelValue:r.num,"onUpdate:modelValue":s[0]||(s[0]=e=>r.num=e),min:1,max:10,label:"描述文字"},null,8,["modelValue"])])),_:1}),m(f,{title:"禁用状态",class:"demo"},{default:o((()=>[m(c,{modelValue:r.num2,"onUpdate:modelValue":s[1]||(s[1]=e=>r.num2=e),disabled:!0},null,8,["modelValue"])])),_:1}),m(f,{title:"步数",class:"demo"},{default:o((()=>[m(c,{modelValue:r.num3,"onUpdate:modelValue":s[2]||(s[2]=e=>r.num3=e),step:2},null,8,["modelValue"])])),_:1}),m(f,{title:"精度",class:"demo"},{default:o((()=>[m(c,{modelValue:r.num4,"onUpdate:modelValue":s[3]||(s[3]=e=>r.num4=e),precision:2,step:.1,max:10},null,8,["modelValue","step"])])),_:1}),m(f,{title:"按钮位置",class:"demo"},{default:o((()=>[m(c,{modelValue:r.num5,"onUpdate:modelValue":s[4]||(s[4]=e=>r.num5=e),"controls-position":"right",min:1,max:10},null,8,["modelValue"])])),_:1})])}]]);export{s as default};
