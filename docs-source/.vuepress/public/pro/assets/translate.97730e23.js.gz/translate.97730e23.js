
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as a,u as e,o as t,c as s,y as o,t as r,i as n,e as l,C as d,D as i,j as p,w as h,g as c,F as m,G as u,H as v,k as f,a as b}from"./index.89c4a536.js";import{E as g,a as y,b as _}from"./el-dropdown-item.fd9a20db.js";import"./el-button.ee77ba8f.js";import"./el-popper.27b489eb.js";const z={class:"copyright"},w=["href"],H={key:1},k=o(" All Rights Reserved ");var L=a({setup(a){const l=e();return(a,e)=>(t(),s("footer",z,[o(" Copyright © "+r(n(l).copyright.dates)+" ",1),n(l).copyright.website?(t(),s("a",{key:0,href:n(l).copyright.website,target:"_blank",rel:"noopener"},r(n(l).copyright.company)+",",9,w)):(t(),s("span",H,r(n(l).copyright.company)+",",1)),k]))}},[["__scopeId","data-v-7586fb9c"]]);var V=a({setup(a){const b=e(),{locale:z}=l(),w=d((()=>i()));function H(a){z.value=a,b.setDefaultLang(a)}return(a,e)=>{const l=g,d=y,i=_;return n(b).topbar.enableI18n?(t(),p(i,{key:0,class:"language-container",size:"default",onCommand:H},{dropdown:h((()=>[c(d,null,{default:h((()=>[(t(!0),s(u,null,m(n(w),((a,e)=>(t(),p(l,{key:e,disabled:n(b).app.defaultLang===a.name,command:a.name},{default:h((()=>[o(r(a.labelName),1)])),_:2},1032,["disabled","command"])))),128))])),_:1})])),default:h((()=>[v(a.$slots,"default",{},void 0,!0)])),_:3})):f("v-if",!0)}}},[["__scopeId","data-v-7d01a656"]]);const j={preserveAspectRatio:"xMidYMid meet",viewBox:"0 0 24 24",width:"1em",height:"1em"},M=[b("path",{fill:"currentColor",d:"M5 15v2a2 2 0 0 0 1.85 1.995L7 19h3v2H7a4 4 0 0 1-4-4v-2h2zm13-5l4.4 11h-2.155l-1.201-3h-4.09l-1.199 3h-2.154L16 10h2zm-1 2.885L15.753 16h2.492L17 12.885zM8 2v2h4v7H8v3H6v-3H2V4h4V2h2zm9 1a4 4 0 0 1 4 4v2h-2V7a2 2 0 0 0-2-2h-3V3h3zM6 6H4v3h2V6zm4 0H8v3h2V6z"},null,-1)];var x={name:"ri-translate",render:function(a,e){return t(),s("svg",j,M)}};export{V as _,L as a,x as b};
