
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.538e7de7.js";import{_ as l}from"./index.d429e7e3.js";import{_ as a,c as d,b as u,w as t,m as o,n as m}from"./index.25647206.js";var s=a({data:()=>({value:!0,value1:!0,value2:!0,value3:!1})},[["render",function(a,s,i,n,v,r){const c=l,V=o("el-switch"),f=e;return m(),d("div",null,[u(c),u(f,{title:"基础用法",class:"demo"},{default:t((()=>[u(V,{modelValue:v.value,"onUpdate:modelValue":s[0]||(s[0]=e=>v.value=e),"active-color":"#13ce66","inactive-color":"#ff4949"},null,8,["modelValue"])])),_:1}),u(f,{title:"文字描述",class:"demo"},{default:t((()=>[u(V,{modelValue:v.value1,"onUpdate:modelValue":s[1]||(s[1]=e=>v.value1=e),"active-text":"按月付费","inactive-text":"按年付费"},null,8,["modelValue"])])),_:1}),u(f,{title:"禁用状态",class:"demo"},{default:t((()=>[u(V,{modelValue:v.value2,"onUpdate:modelValue":s[2]||(s[2]=e=>v.value2=e),disabled:"",style:{"margin-right":"10px"}},null,8,["modelValue"]),u(V,{modelValue:v.value3,"onUpdate:modelValue":s[3]||(s[3]=e=>v.value3=e),disabled:""},null,8,["modelValue"])])),_:1})])}]]);export{s as default};
