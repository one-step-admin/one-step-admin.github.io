
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.15becada.js";import{u as a,C as t,c as o,b as r,w as s,n,f as i,an as l,y as d}from"./index.0a5e3bc2.js";/* empty css                       *//* empty css                        */import{_ as f}from"./index.7bc6f31f.js";import{E as m,a as p}from"./index2.841f0948.js";/* empty css                */import"./index.5fef9d7d.js";import"./index2.f37a6952.js";import"./event2.27558ffe.js";import"./index2.fa2fe4ab.js";import"./error2.1d524120.js";const u=d("开启"),c=d("关闭"),b={setup(d){const b=a(),j=t({get:function(){return b.app.enableWatermark},set:function(e){b.$patch((a=>{a.app.enableWatermark=e}))}});return(a,t)=>{const d=f,b=m,x=p,_=e;return n(),o("div",null,[r(d,{title:"页面水印",content:"在某些场景下，不希望用户将系统里的信息随意截图并转发，这时可开启页面水印，以减少这种情况发生"}),r(_,{title:"可在 src\\layout\\components\\Watermark\\index.vue 文件里定制水印文案内容"},{default:s((()=>[r(x,{modelValue:i(j),"onUpdate:modelValue":t[0]||(t[0]=e=>l(j)?j.value=e:null)},{default:s((()=>[r(b,{label:!0},{default:s((()=>[u])),_:1}),r(b,{label:!1},{default:s((()=>[c])),_:1})])),_:1},8,["modelValue"])])),_:1})])}}};export{b as default};
