
/**
 * 由 Fantastic-admin-discovery 提供技术支持
 * https://hooray.gitee.io/fantastic-admin-discovery/
 * Powered by Fantastic-admin-discovery
 * https://hooray.github.io/fantastic-admin-discovery/
 */
    
import{_ as c}from"./plugin-vue_export-helper.5a098b48.js";import{a4 as i,o as a,I as s,Q as r,M as l,Z as p,U as d,V as u,O as _,P as f,J as v}from"./vendor.6b4522dc.js";const h=e=>(_("data-v-6a4cf472"),e=e(),f(),e),m={key:0,class:"title-container"},g=h(()=>v("i",{class:"el-icon-arrow-down"},null,-1)),y=[g],S={props:{title:{type:String,default:""},collaspe:{type:Boolean,default:!1},height:{type:String,default:""}},setup(e){const t=i(e.collaspe);function o(){t.value=!1}return(n,x)=>(a(),s("div",{class:d({"page-main":!0,"is-collaspe":t.value}),style:u({height:t.value?e.height:""})},[e.title?(a(),s("div",m,r(e.title),1)):l("v-if",!0),p(n.$slots,"default",{},void 0,!0),t.value?(a(),s("div",{key:1,class:"collaspe",title:"\u5C55\u5F00",onClick:o},y)):l("v-if",!0)],6))}};var C=c(S,[["__scopeId","data-v-6a4cf472"]]);export{C as _};
