
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as a}from"./index.15becada.js";import{_ as t}from"./index.7bc6f31f.js";import{_ as i,c as s,b as e,w as n,n as l,p as d,k as o,e as c}from"./index.0a5e3bc2.js";/* empty css                */import"./index.5fef9d7d.js";const r={},m=a=>(d("data-v-09535066"),a=a(),o(),a),p=m((()=>c("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),f=m((()=>c("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),_=m((()=>c("p",{class:"digital-7"},"Fantastic-admin",-1))),b=m((()=>c("p",{class:"digital-7"},"1234567890,.",-1))),g=m((()=>c("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),u=m((()=>c("p",{class:"digital-7_mono"},"1234567890,.",-1)));var j=i(r,[["render",function(i,d){const o=t,c=a;return l(),s("div",null,[e(o,{title:"自定义字体"},{content:n((()=>[p,f])),_:1}),e(c,{title:"Digital 7"},{default:n((()=>[_,b])),_:1}),e(c,{title:"Digital 7（等宽）"},{default:n((()=>[g,u])),_:1})])}],["__scopeId","data-v-09535066"]]);export{j as default};
