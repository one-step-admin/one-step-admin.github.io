
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.15becada.js";import{c0 as n,E as a,c as t,b as s,w as i,n as o,e as r,t as u,f,y as l}from"./index.0a5e3bc2.js";import{E as m}from"./el-button.2fada245.js";/* empty css                */import{_ as d}from"./index.5fef9d7d.js";import{_ as c}from"./index.7bc6f31f.js";import"./index2.f37a6952.js";import"./index2.2a4e9295.js";import"./index2.fa2fe4ab.js";const b=l(" 1 "),p=l(" 1 "),j={setup(l){const j=n();function x(){j.setNumber(j.number+1)}function _(){j.setNumber(j.number-1)}return(n,l)=>{const k=c,v=d,C=a,E=m,N=e;return o(),t("div",null,[s(k,{title:"数字标记",content:"搭配 Pinia 可实现动态设置。请控制数字展示长度，避免导航标记覆盖导航标题，为 0 时则隐藏"}),s(N,null,{default:i((()=>[r("div",null,"当前 badge 值："+u(f(j).number),1),s(E,{onClick:x},{icon:i((()=>[s(C,null,{default:i((()=>[s(v,{name:"ep:plus"})])),_:1})])),default:i((()=>[b])),_:1}),s(E,{onClick:_},{icon:i((()=>[s(C,null,{default:i((()=>[s(v,{name:"ep:minus"})])),_:1})])),default:i((()=>[p])),_:1})])),_:1})])}}};export{j as default};
