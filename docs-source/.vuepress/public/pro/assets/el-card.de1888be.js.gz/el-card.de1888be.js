
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
var e=Object.defineProperty,a=Object.defineProperties,r=Object.getOwnPropertyDescriptors,s=Object.getOwnPropertySymbols,t=Object.prototype.hasOwnProperty,o=Object.prototype.propertyIsEnumerable,l=(a,r,s)=>r in a?e(a,r,{enumerable:!0,configurable:!0,writable:!0,value:s}):a[r]=s;import{I as d,M as n,d as c,J as p,o as i,c as y,a1 as b,i as u,H as f,y as h,t as m,k as v,a as O,ab as w,a2 as j,L as g}from"./index.89c4a536.js";const S=d({header:{type:String,default:""},bodyStyle:{type:n([String,Object,Array]),default:""},shadow:{type:String,default:"always"}}),P=c((k=((e,a)=>{for(var r in a||(a={}))t.call(a,r)&&l(e,r,a[r]);if(s)for(var r of s(a))o.call(a,r)&&l(e,r,a[r]);return e})({},{name:"ElCard"}),a(k,r({props:S,setup(e){const a=p("card");return(e,r)=>(i(),y("div",{class:b([u(a).b(),u(a).is(`${e.shadow}-shadow`)])},[e.$slots.header||e.header?(i(),y("div",{key:0,class:b(u(a).e("header"))},[f(e.$slots,"header",{},(()=>[h(m(e.header),1)]))],2)):v("v-if",!0),O("div",{class:b(u(a).e("body")),style:w(e.bodyStyle)},[f(e.$slots,"default")],6)],2))}}))));var k;const $=g(j(P,[["__file","/home/runner/work/element-plus/element-plus/packages/components/card/src/card.vue"]]));export{$ as E};
