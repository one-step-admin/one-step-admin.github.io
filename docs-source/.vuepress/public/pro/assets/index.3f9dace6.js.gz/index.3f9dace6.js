
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.fef54795.js";import{_ as l}from"./index.8e0d1c11.js";import{_ as a}from"./index.8d8a4cfe.js";import{k as o,A as d,x as t,z as u,o as s}from"./vendor.b0dde714.js";var m=a({data:()=>({value1:null,value2:null,value3:3.7})},[["render",function(a,m,r,n,f,i){const v=l,c=u("el-rate"),p=e;return s(),o("div",null,[d(v),d(p,{title:"基础用法",class:"demo"},{default:t((()=>[d(c,{modelValue:f.value1,"onUpdate:modelValue":m[0]||(m[0]=e=>f.value1=e)},null,8,["modelValue"])])),_:1}),d(p,{title:"辅助文字",class:"demo"},{default:t((()=>[d(c,{modelValue:f.value2,"onUpdate:modelValue":m[1]||(m[1]=e=>f.value2=e),"show-text":"",texts:["极差","差","一般","好","极好"]},null,8,["modelValue"])])),_:1}),d(p,{title:"只读",class:"demo"},{default:t((()=>[d(c,{modelValue:f.value3,"onUpdate:modelValue":m[2]||(m[2]=e=>f.value3=e),disabled:"","show-score":"","text-color":"#ff9900","score-template":"{value}"},null,8,["modelValue"])])),_:1})])}]]);export{m as default};
