
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as u,u as i,g as w}from"./index.e7d2f5e5.js";import{o,k as s,$ as d,Y as r,u as e,s as k,z as l,t as m,x as _,A as b,a1 as C,a2 as S,a3 as $,m as I,C as L}from"./vendor.ac88770c.js";const N={class:"copyright"},B=["href"],V={key:1},j=d(" All Rights Reserved "),z={setup(g){const t=i();return(n,p)=>(o(),s("footer",N,[d(" Copyright \xA9 "+r(e(t).copyright.dates)+" ",1),e(t).copyright.website?(o(),s("a",{key:0,href:e(t).copyright.website,target:"_blank",rel:"noopener"},r(e(t).copyright.company)+",",9,B)):(o(),s("span",V,r(e(t).copyright.company)+",",1)),j]))}};var F=u(z,[["__scopeId","data-v-21d46e6a"]]);const A={setup(g){const{proxy:t}=L(),n=i(),p=k(()=>w());function f(a){t.$i18n.locale=a,n.setDefaultLang(a)}return(a,D)=>{const y=l("el-dropdown-item"),h=l("el-dropdown-menu"),v=l("el-dropdown");return e(n).topbar.enableI18n?(o(),m(v,{key:0,class:"language-container",size:"default",onCommand:f},{dropdown:_(()=>[b(h,null,{default:_(()=>[(o(!0),s(S,null,C(e(p),(c,x)=>(o(),m(y,{key:x,disabled:e(n).app.defaultLang===c.name,command:c.name},{default:_(()=>[d(r(c.labelName),1)]),_:2},1032,["disabled","command"]))),128))]),_:1})]),default:_(()=>[$(a.$slots,"default",{},void 0,!0)]),_:3})):I("v-if",!0)}}};var T=u(A,[["__scopeId","data-v-898ff48c"]]);export{T as _,F as a};
