
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.538e7de7.js";import{_ as l}from"./index.d429e7e3.js";import{_ as a,c as d,b as t,w as o,m as u,n}from"./index.25647206.js";var i=a({data:()=>({input:"",input1:"",input2:"",textarea:""})},[["render",function(a,i,p,m,s,r){const c=l,V=u("el-input"),f=e;return n(),d("div",null,[t(c),t(f,{title:"基础用法",class:"demo"},{default:o((()=>[t(V,{modelValue:s.input,"onUpdate:modelValue":i[0]||(i[0]=e=>s.input=e),placeholder:"请输入内容"},null,8,["modelValue"])])),_:1}),t(f,{title:"禁用状态",class:"demo"},{default:o((()=>[t(V,{modelValue:s.input,"onUpdate:modelValue":i[1]||(i[1]=e=>s.input=e),placeholder:"请输入内容",disabled:!0},null,8,["modelValue"])])),_:1}),t(f,{title:"可清空",class:"demo"},{default:o((()=>[t(V,{modelValue:s.input,"onUpdate:modelValue":i[2]||(i[2]=e=>s.input=e),placeholder:"请输入内容",clearable:""},null,8,["modelValue"])])),_:1}),t(f,{title:"密码框",class:"demo"},{default:o((()=>[t(V,{modelValue:s.input,"onUpdate:modelValue":i[3]||(i[3]=e=>s.input=e),placeholder:"请输入内容","show-password":""},null,8,["modelValue"])])),_:1}),t(f,{title:"带 icon 的输入框",class:"demo"},{default:o((()=>[t(V,{modelValue:s.input1,"onUpdate:modelValue":i[4]||(i[4]=e=>s.input1=e),placeholder:"请选择日期","suffix-icon":"el-icon-calendar"},null,8,["modelValue"]),t(V,{modelValue:s.input2,"onUpdate:modelValue":i[5]||(i[5]=e=>s.input2=e),placeholder:"请输入内容","prefix-icon":"el-icon-search"},null,8,["modelValue"])])),_:1}),t(f,{title:"文本域",class:"demo"},{default:o((()=>[t(V,{modelValue:s.textarea,"onUpdate:modelValue":i[6]||(i[6]=e=>s.textarea=e),type:"textarea",rows:2,placeholder:"请输入内容"},null,8,["modelValue"])])),_:1})])}]]);export{i as default};
