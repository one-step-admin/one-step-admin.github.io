
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.15becada.js";import{_ as o,n as t,i as a,w as r,y as d,t as n,e as f,b as i,j as l,aa as c,E as s,c as m}from"./index.0a5e3bc2.js";import{E as u}from"./el-row.5ffdf9e2.js";import{E as p}from"./el-col.3759f1e4.js";import{E as _}from"./el-card.86e25d8c.js";/* empty css                */import{_ as b}from"./index.5fef9d7d.js";import{_ as g}from"./index.7bc6f31f.js";import"./typescript2.7477ece2.js";const y={class:"num"},j={class:"tip"};var x=o({props:{colorFrom:{type:String,default:"#843cf6"},colorTo:{type:String,default:"#759bff"},header:{type:String,default:""},num:{type:Number,default:0},tip:{type:String,default:""},icon:{type:String,default:""}},setup:e=>(o,m)=>{const u=b,p=s,g=_;return t(),a(g,{shadow:"hover",class:"mini-card",style:c({background:`linear-gradient(50deg, ${e.colorFrom}, ${e.colorTo})`})},{header:r((()=>[d(n(e.header),1)])),default:r((()=>[f("div",y,n(e.num),1),f("div",j,n(e.tip),1),e.icon?(t(),a(p,{key:0},{default:r((()=>[i(u,{name:e.icon,rotate:20},null,8,["name"])])),_:1})):l("v-if",!0)])),_:1},8,["style"])}},[["__scopeId","data-v-8eb08d5e"]]);var h=o({},[["render",function(o,a){const d=g,n=x,f=p,l=u,c=e;return t(),m("div",null,[i(d,{title:"多彩渐变卡片",content:"ColorfulCard"}),i(c,null,{default:r((()=>[i(l,{gutter:20},{default:r((()=>[i(f,{md:12},{default:r((()=>[i(n,{header:"开发文档",num:123,tip:"较上周上升50%",icon:"index-document"})])),_:1}),i(f,{md:12},{default:r((()=>[i(n,{"color-from":"#fbaaa2","color-to":"#fc5286",header:"基础组件",num:12323,tip:"较上周上升50%",icon:"index-component"})])),_:1})])),_:1}),i(l,{gutter:20,style:{"margin-top":"20px"}},{default:r((()=>[i(f,{md:12},{default:r((()=>[i(n,{"color-from":"#ff763b","color-to":"#ffc480",header:"扩展组件",num:123,tip:"较上周上升50%",icon:"index-component"})])),_:1}),i(f,{md:12},{default:r((()=>[i(n,{"color-from":"#6a8eff","color-to":"#0e4cfd",header:"业务应用页面",num:123,tip:"较上周上升50%",icon:"index-page"})])),_:1})])),_:1})])),_:1})])}]]);export{h as default};
