
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.538e7de7.js";import{_ as t}from"./index.4b60663a.js";import{_ as a}from"./index.bc6ef411.js";import{_ as s,c as l,b as r,w as d,m as i,n,y as u,e as f}from"./index.25647206.js";const o={},m=u("返回列表"),p=u("打印"),_=f("div",null,"您提交的内容有如下错误：",-1),c=f("div",null,[u(" 您的账户已被冻结 "),f("a",{href:"###"},"打印")],-1),y=u("返回修改");var x=s(o,[["render",function(s,u){const f=a,o=i("el-button"),x=t,b=e;return n(),l("div",null,[r(f,{title:"处理结果",content:"Result"}),r(b,{title:"成功"},{default:d((()=>[r(x,{type:"success",title:"提交成功",desc:"提交结果页用于反馈一系列操作任务的处理结果。"},{default:d((()=>[r(o,{type:"primary"},{default:d((()=>[m])),_:1}),r(o,null,{default:d((()=>[p])),_:1})])),_:1})])),_:1}),r(b,{title:"失败"},{default:d((()=>[r(x,{type:"error",title:"提交失败",desc:"灰色额外区域可以显示一些补充的信息。请核对并修改以下信息后，再重新提交。"},{extra:d((()=>[_,c])),default:d((()=>[r(o,{type:"primary"},{default:d((()=>[y])),_:1})])),_:1})])),_:1})])}]]);export{x as default};
