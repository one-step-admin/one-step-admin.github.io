
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.7ae327c0.js";import{_ as l,c as a,g as o,w as t,o as d}from"./index.89c4a536.js";import{E as i}from"./el-switch.48ce42ad.js";import{_ as u}from"./index.bca90ab2.js";/* empty css                */import"./validator.0261e922.js";import"./event.87cd92d6.js";import"./index.a744c982.js";import"./index.0dfe2aba.js";import"./error.67356979.js";import"./el-alert.5b00153b.js";import"./el-link.2134bbaa.js";var m=l({data:()=>({value:!0,value1:!0,value2:!0,value3:!1})},[["render",function(l,m,s,r,n,c){const v=u,p=i,f=e;return d(),a("div",null,[o(v),o(f,{title:"基础用法",class:"demo"},{default:t((()=>[o(p,{modelValue:n.value,"onUpdate:modelValue":m[0]||(m[0]=e=>n.value=e),"active-color":"#13ce66","inactive-color":"#ff4949"},null,8,["modelValue"])])),_:1}),o(f,{title:"文字描述",class:"demo"},{default:t((()=>[o(p,{modelValue:n.value1,"onUpdate:modelValue":m[1]||(m[1]=e=>n.value1=e),"active-text":"按月付费","inactive-text":"按年付费"},null,8,["modelValue"])])),_:1}),o(f,{title:"禁用状态",class:"demo"},{default:t((()=>[o(p,{modelValue:n.value2,"onUpdate:modelValue":m[2]||(m[2]=e=>n.value2=e),disabled:"",style:{"margin-right":"10px"}},null,8,["modelValue"]),o(p,{modelValue:n.value3,"onUpdate:modelValue":m[3]||(m[3]=e=>n.value3=e),disabled:""},null,8,["modelValue"])])),_:1})])}]]);export{m as default};
