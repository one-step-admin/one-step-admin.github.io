
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.7ae327c0.js";import{b$ as n,E as a,c as t,g as s,w as i,o,a as u,t as r,i as l,y as m}from"./index.89c4a536.js";import{E as f}from"./el-button.ee77ba8f.js";/* empty css                */import{_ as c}from"./index.2a4f1e1c.js";import{_ as d}from"./index.60634e19.js";import"./index.0dfe2aba.js";import"./index.a744c982.js";const p=m(" 1 "),b=m(" 1 "),j={setup(m){const j=n();function _(){j.setNumber(j.number+1)}function x(){j.setNumber(j.number-1)}return(n,m)=>{const g=d,k=c,v=a,C=f,E=e;return o(),t("div",null,[s(g,{title:"数字标记",content:"搭配 Pinia 可实现动态设置。请控制数字展示长度，避免导航标记覆盖导航标题，为 0 时则隐藏"}),s(E,null,{default:i((()=>[u("div",null,"当前 badge 值："+r(l(j).number),1),s(C,{onClick:_},{icon:i((()=>[s(v,null,{default:i((()=>[s(k,{name:"ep:plus"})])),_:1})])),default:i((()=>[p])),_:1}),s(C,{onClick:x},{icon:i((()=>[s(v,null,{default:i((()=>[s(k,{name:"ep:minus"})])),_:1})])),default:i((()=>[b])),_:1})])),_:1})])}}};export{j as default};
