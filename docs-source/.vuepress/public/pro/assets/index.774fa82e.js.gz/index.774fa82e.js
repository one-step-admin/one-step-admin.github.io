
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e,E as a,c as t,g as l,w as d,o as s,y as i}from"./index.89c4a536.js";/* empty css                */import{_ as f}from"./index.2a4f1e1c.js";import{_ as n}from"./index.7ae327c0.js";import{E as u}from"./el-link.2134bbaa.js";import{_ as r}from"./index.bca90ab2.js";import"./el-alert.5b00153b.js";const _={},o=i("默认链接"),p=i("主要链接"),c=i("成功链接"),m=i("警告链接"),b=i("危险链接"),y=i("信息链接"),g=i("默认链接"),j=i("主要链接"),x=i("成功链接"),v=i("警告链接"),w=i("危险链接"),h=i("信息链接"),k=i("无下划线"),E=i("有下划线"),I=i(" 编辑 "),q=i(" 查看 ");var z=e(_,[["render",function(e,i){const _=r,z=u,A=n,B=f,C=a;return s(),t("div",null,[l(_),l(A,{title:"基础用法",class:"demo"},{default:d((()=>[l(z,{href:"https://element.eleme.io",target:"_blank"},{default:d((()=>[o])),_:1}),l(z,{type:"primary"},{default:d((()=>[p])),_:1}),l(z,{type:"success"},{default:d((()=>[c])),_:1}),l(z,{type:"warning"},{default:d((()=>[m])),_:1}),l(z,{type:"danger"},{default:d((()=>[b])),_:1}),l(z,{type:"info"},{default:d((()=>[y])),_:1})])),_:1}),l(A,{title:"禁用状态",class:"demo"},{default:d((()=>[l(z,{disabled:""},{default:d((()=>[g])),_:1}),l(z,{type:"primary",disabled:""},{default:d((()=>[j])),_:1}),l(z,{type:"success",disabled:""},{default:d((()=>[x])),_:1}),l(z,{type:"warning",disabled:""},{default:d((()=>[v])),_:1}),l(z,{type:"danger",disabled:""},{default:d((()=>[w])),_:1}),l(z,{type:"info",disabled:""},{default:d((()=>[h])),_:1})])),_:1}),l(A,{title:"下划线",class:"demo"},{default:d((()=>[l(z,{underline:!1},{default:d((()=>[k])),_:1}),l(z,null,{default:d((()=>[E])),_:1})])),_:1}),l(A,{title:"图标",class:"demo"},{default:d((()=>[l(z,null,{default:d((()=>[l(C,{class:"el-icon--left"},{default:d((()=>[l(B,{name:"ep:edit"})])),_:1}),I])),_:1}),l(z,null,{default:d((()=>[q,l(C,{class:"el-icon--right"},{default:d((()=>[l(B,{name:"ep:view"})])),_:1})])),_:1})])),_:1})])}],["__scopeId","data-v-484ff390"]]);export{z as default};
