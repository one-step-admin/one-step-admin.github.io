
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as f}from"./index.836a9402.js";import{_ as m}from"./index.9d0f40da.js";import{x as a,an as g,k as r,A as l,z as o,o as _,V as v,l as n,$ as d}from"./vendor.4acdc30d.js";const V={data(){return{dialogVisible:!1}}},x=d("\u70B9\u51FB\u6253\u5F00 Dialog"),b=n("div",null," \u6309\u4F4F\u6211\u8FDB\u884C\u62D6\u52A8 ",-1),k=n("span",null,"\u8FD9\u662F\u4E00\u6BB5\u4FE1\u606F",-1),C={class:"dialog-footer"},j=d("\u53D6 \u6D88"),w=d("\u786E \u5B9A");function y(B,e,D,N,t,$){const s=a("el-button"),p=a("el-dialog"),u=f,c=g("drag");return _(),r("div",null,[l(u,null,{default:o(()=>[l(s,{type:"text",onClick:e[0]||(e[0]=i=>t.dialogVisible=!0)},{default:o(()=>[x]),_:1}),v((_(),r("div",null,[l(p,{modelValue:t.dialogVisible,"onUpdate:modelValue":e[3]||(e[3]=i=>t.dialogVisible=i),width:"30%"},{title:o(()=>[b]),footer:o(()=>[n("span",C,[l(s,{onClick:e[1]||(e[1]=i=>t.dialogVisible=!1)},{default:o(()=>[j]),_:1}),l(s,{type:"primary",onClick:e[2]||(e[2]=i=>t.dialogVisible=!1)},{default:o(()=>[w]),_:1})])]),default:o(()=>[k]),_:1},8,["modelValue"])])),[[c]])]),_:1})])}var E=m(V,[["render",y]]);export{E as default};
