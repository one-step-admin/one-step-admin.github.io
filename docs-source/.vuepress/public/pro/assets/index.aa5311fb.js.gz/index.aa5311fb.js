
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as a,u as e,n as s,c as t,y as o,t as n,f as r,v as l,C as p,D as d,i,w as c,b as f,F as u,G as m,H as y,j as g}from"./index.0a5e3bc2.js";import{E as b,a as h,b as _}from"./el-dropdown-item.389ff654.js";import"./el-button.2fada245.js";import"./el-popper.807071fe.js";const v={class:"copyright"},j=["href"],k={key:1},w=o(" All Rights Reserved ");var I=a({setup(a){const l=e();return(a,e)=>(s(),t("footer",v,[o(" Copyright © "+n(r(l).copyright.dates)+" ",1),r(l).copyright.website?(s(),t("a",{key:0,href:r(l).copyright.website,target:"_blank",rel:"noopener"},n(r(l).copyright.company)+",",9,j)):(s(),t("span",k,n(r(l).copyright.company)+",",1)),w]))}},[["__scopeId","data-v-2a579a08"]]);var x=a({setup(a){const v=e(),{locale:j}=l.exports.useI18n(),k=p((()=>d()));function w(a){j.value=a,v.setDefaultLang(a)}return(a,e)=>{const l=b,p=h,d=_;return r(v).topbar.enableI18n?(s(),i(d,{key:0,class:"language-container",size:"default",onCommand:w},{dropdown:c((()=>[f(p,null,{default:c((()=>[(s(!0),t(m,null,u(r(k),((a,e)=>(s(),i(l,{key:e,disabled:r(v).app.defaultLang===a.name,command:a.name},{default:c((()=>[o(n(a.labelName),1)])),_:2},1032,["disabled","command"])))),128))])),_:1})])),default:c((()=>[y(a.$slots,"default",{},void 0,!0)])),_:3})):g("v-if",!0)}}},[["__scopeId","data-v-38d676f7"]]);export{x as _,I as a};
