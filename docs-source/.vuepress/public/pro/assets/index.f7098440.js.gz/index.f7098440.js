
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.7ae327c0.js";import{_ as o,o as t,j as a,w as r,y as d,t as n,a as i,g as l,k as f,ab as s,E as c,c as m}from"./index.89c4a536.js";import{E as u}from"./el-row.589e4137.js";import{E as p}from"./el-col.1980009e.js";import{E as _}from"./el-card.de1888be.js";/* empty css                */import{_ as g}from"./index.2a4f1e1c.js";import{_ as y}from"./index.60634e19.js";import"./typescript.f55dff19.js";const b={class:"num"},j={class:"tip"};var x=o({props:{colorFrom:{type:String,default:"#843cf6"},colorTo:{type:String,default:"#759bff"},header:{type:String,default:""},num:{type:Number,default:0},tip:{type:String,default:""},icon:{type:String,default:""}},setup:e=>(o,m)=>{const u=g,p=c,y=_;return t(),a(y,{shadow:"hover",class:"mini-card",style:s({background:`linear-gradient(50deg, ${e.colorFrom}, ${e.colorTo})`})},{header:r((()=>[d(n(e.header),1)])),default:r((()=>[i("div",b,n(e.num),1),i("div",j,n(e.tip),1),e.icon?(t(),a(p,{key:0},{default:r((()=>[l(u,{name:e.icon,rotate:20},null,8,["name"])])),_:1})):f("v-if",!0)])),_:1},8,["style"])}},[["__scopeId","data-v-8eb08d5e"]]);var h=o({},[["render",function(o,a){const d=y,n=x,i=p,f=u,s=e;return t(),m("div",null,[l(d,{title:"多彩渐变卡片",content:"ColorfulCard"}),l(s,null,{default:r((()=>[l(f,{gutter:20},{default:r((()=>[l(i,{md:12},{default:r((()=>[l(n,{header:"开发文档",num:123,tip:"较上周上升50%",icon:"index-document"})])),_:1}),l(i,{md:12},{default:r((()=>[l(n,{"color-from":"#fbaaa2","color-to":"#fc5286",header:"基础组件",num:12323,tip:"较上周上升50%",icon:"index-component"})])),_:1})])),_:1}),l(f,{gutter:20,style:{"margin-top":"20px"}},{default:r((()=>[l(i,{md:12},{default:r((()=>[l(n,{"color-from":"#ff763b","color-to":"#ffc480",header:"扩展组件",num:123,tip:"较上周上升50%",icon:"index-component"})])),_:1}),l(i,{md:12},{default:r((()=>[l(n,{"color-from":"#6a8eff","color-to":"#0e4cfd",header:"业务应用页面",num:123,tip:"较上周上升50%",icon:"index-page"})])),_:1})])),_:1})])),_:1})])}]]);export{h as default};
