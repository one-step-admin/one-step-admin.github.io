
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as a}from"./index.7ae327c0.js";import{_ as e}from"./index.60634e19.js";import{_ as t}from"./logo.d77fe55e.js";import{_ as l,c as n,g as s,w as i,o,y as r,a as c}from"./index.89c4a536.js";/* empty css                */const d={},f=r(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),m=r(" 这里放页面内容 "),u=c("h1",null,"Fantastic-admin",-1),p=c("img",{src:t},null,-1),_=c("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);var g=l(d,[["render",function(t,l){const r=e,c=a;return o(),n("div",null,[s(r,{title:"内容块",content:"PageMain"}),s(c,null,{default:i((()=>[f])),_:1}),s(c,{title:"你可以设置一个自定义的标题"},{default:i((()=>[m])),_:1}),s(c,{title:"带展开功能",collaspe:"",height:"200px"},{default:i((()=>[u,p,_])),_:1})])}]]);export{g as default};
