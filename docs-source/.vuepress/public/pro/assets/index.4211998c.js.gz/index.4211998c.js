
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e,E as t,c as a,b as n,w as o,n as r,e as s,y as i}from"./index.0a5e3bc2.js";import{E as f}from"./el-button.2fada245.js";/* empty css                */import{_ as d}from"./index.5fef9d7d.js";import{_ as l}from"./index.7bc6f31f.js";import"./index2.f37a6952.js";import"./index2.2a4e9295.js";import"./index2.fa2fe4ab.js";const m={},p=s("p",null,"提供两块插槽：",-1),u=s("p",null,"一块是 content 区域插槽，一块是右侧区域",-1),c=i(" 返回 ");var j=e(m,[["render",function(e,s){const i=l,m=d,j=t,b=f;return r(),a("div",null,[n(i,{title:"页头",content:"PageHeader"}),n(i,{title:"页面标题"},{content:o((()=>[p,u])),default:o((()=>[n(b,{round:""},{icon:o((()=>[n(j,null,{default:o((()=>[n(m,{name:"ep:arrow-left"})])),_:1})])),default:o((()=>[c])),_:1})])),_:1})])}]]);export{j as default};
