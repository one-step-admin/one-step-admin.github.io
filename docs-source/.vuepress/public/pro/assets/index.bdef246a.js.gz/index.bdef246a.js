
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as a,E as e,c as s,b as t,w as i,n as o,G as r,F as d,e as f,p as l,k as m,y as n}from"./index.0a5e3bc2.js";import{E as c}from"./el-row.5ffdf9e2.js";import{E as p}from"./el-col.3759f1e4.js";import{E as u}from"./el-card.86e25d8c.js";import{E as j}from"./el-button.2fada245.js";import{E as v}from"./el-avatar.756540b5.js";/* empty css                */import{_}from"./index.5fef9d7d.js";import{_ as b}from"./index.7bc6f31f.js";import"./typescript2.7477ece2.js";import"./index2.f37a6952.js";import"./index2.2a4e9295.js";import"./index2.fa2fe4ab.js";const x={},y={class:"content"},E={class:"item"},g=(a=>(l("data-v-128a0f36"),a=a(),m(),a))((()=>f("div",{class:"item"},[f("div",{class:"name"},"Hooray"),f("div",{class:"intro"},"前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用。前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用")],-1))),w={class:"action-bar"},H=n("操作一"),h=n("操作二");var k=a(x,[["render",function(a,l){const m=b,n=_,x=e,k=v,W=j,z=u,F=p,G=c;return o(),s("div",null,[t(m,{title:"卡片列表",content:"卡片类型的列表，配合栅格实现响应式布局。"}),t(G,{gutter:20,style:{margin:"0 10px"}},{default:i((()=>[(o(),s(r,null,d(12,((a,e)=>t(F,{key:e,lg:6,md:8,sm:12},{default:i((()=>[t(z,{shadow:"hover",class:"action-card"},{default:i((()=>[f("div",y,[f("div",E,[t(k,{size:"medium"},{default:i((()=>[t(x,null,{default:i((()=>[t(n,{name:"ep:user-filled"})])),_:1})])),_:1})]),g]),f("div",w,[t(W,{type:"text"},{default:i((()=>[H])),_:1}),t(W,{type:"text"},{default:i((()=>[h])),_:1})])])),_:1})])),_:2},1024))),64))])),_:1})])}],["__scopeId","data-v-128a0f36"]]);export{k as default};
