
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as n}from"./index.d92f6c0c.js";import{_ as a}from"./index.fadd46b6.js";import{_ as e}from"./index.c2d6d7be.js";import{_ as o}from"./index.091d1180.js";import{k as d,A as i,x as s,z as t,o as l,$ as r}from"./vendor.b0dde714.js";const m={methods:{open(n){window.open(n,"top")}}},c=r("SVG-Loaders 官网");var g=o(m,[["render",function(o,r,m,g,p,f){const u=t("el-button"),_=e,b=a,v=n;return l(),d("div",null,[i(_,{title:"SVG 动画",content:"svg 文件从 SVG-Loaders 中提取，需要注意，svg 均为白色，需要增加底色才能看到效果。如需封装成加载组件，可参考 SpinkitLoading 组件"},{default:s((()=>[i(u,{icon:"el-icon-link",onClick:r[0]||(r[0]=n=>f.open("http://samherbert.net/svg-loaders/"))},{default:s((()=>[c])),_:1})])),_:1}),i(v,{style:{"background-color":"#34495e"}},{default:s((()=>[i(b,{name:"loading-audio"}),i(b,{name:"loading-ball-triangle"}),i(b,{name:"loading-bars"}),i(b,{name:"loading-circles"}),i(b,{name:"loading-grid"}),i(b,{name:"loading-hearts"}),i(b,{name:"loading-oval"}),i(b,{name:"loading-puff"}),i(b,{name:"loading-rings"}),i(b,{name:"loading-spinning-circles"}),i(b,{name:"loading-tail-spin"}),i(b,{name:"loading-three-dots"})])),_:1})])}],["__scopeId","data-v-3c13ccc0"]]);export{g as default};
