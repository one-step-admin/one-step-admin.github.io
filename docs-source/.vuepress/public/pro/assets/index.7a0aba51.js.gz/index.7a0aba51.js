
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e,E as a,c as s,g as t,w as o,o as r,G as i,F as d,a as l,p as f,l as m,y as n}from"./index.b046d3e8.js";import{E as c}from"./el-row.d9220e4c.js";import{E as p}from"./el-col.62e05cfa.js";import{E as u}from"./el-card.fe3fee4d.js";import{E as b}from"./el-button.12f8eb95.js";import{E as j}from"./el-avatar.38808dd3.js";/* empty css                */import{_ as v}from"./index.f1e68254.js";import{_}from"./index.f15ab100.js";import"./typescript.14beffb5.js";import"./index.2b0c4341.js";import"./index.16ef6f7e.js";const x={},y={class:"content"},E={class:"item"},g=(e=>(f("data-v-128a0f36"),e=e(),m(),e))((()=>l("div",{class:"item"},[l("div",{class:"name"},"Hooray"),l("div",{class:"intro"},"前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用。前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用")],-1))),w={class:"action-bar"},H=n("操作一"),h=n("操作二");var W=e(x,[["render",function(e,f){const m=_,n=v,x=a,W=j,k=b,z=u,F=p,G=c;return r(),s("div",null,[t(m,{title:"卡片列表",content:"卡片类型的列表，配合栅格实现响应式布局。"}),t(G,{gutter:20,style:{margin:"0 10px"}},{default:o((()=>[(r(),s(i,null,d(12,((e,a)=>t(F,{key:a,lg:6,md:8,sm:12},{default:o((()=>[t(z,{shadow:"hover",class:"action-card"},{default:o((()=>[l("div",y,[l("div",E,[t(W,{size:"medium"},{default:o((()=>[t(x,null,{default:o((()=>[t(n,{name:"ep:user-filled"})])),_:1})])),_:1})]),g]),l("div",w,[t(k,{type:"text"},{default:o((()=>[H])),_:1}),t(k,{type:"text"},{default:o((()=>[h])),_:1})])])),_:1})])),_:2},1024))),64))])),_:1})])}],["__scopeId","data-v-128a0f36"]]);export{W as default};
