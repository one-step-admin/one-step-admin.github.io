
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e,r as a,n as t,c as s,t as l,j as i,H as o,b as n,w as c,$ as r,aa as d,E as p}from"./index.0a5e3bc2.js";/* empty css                */import{_ as u}from"./index.5fef9d7d.js";const f={key:0,class:"title-container"};var v=e({props:{title:{type:String,default:""},collaspe:{type:Boolean,default:!1},height:{type:String,default:""}},setup(e){const v=a(e.collaspe);function m(){v.value=!1}return(a,g)=>{const h=u,y=p;return t(),s("div",{class:r({"page-main":!0,"is-collaspe":v.value}),style:d({height:v.value?e.height:""})},[e.title?(t(),s("div",f,l(e.title),1)):i("v-if",!0),o(a.$slots,"default",{},void 0,!0),v.value?(t(),s("div",{key:1,class:"collaspe",title:"展开",onClick:m},[n(y,null,{default:c((()=>[n(h,{name:"i-ep:arrow-down"})])),_:1})])):i("v-if",!0)],6)}}},[["__scopeId","data-v-2c39de2e"]]);export{v as _};
