
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.d92f6c0c.js";import{_ as t}from"./index.eb9cb6ff.js";import{_ as r}from"./index.c2d6d7be.js";import{_ as a}from"./index.091d1180.js";import{k as d,A as s,x as l,z as i,o,$ as f,l as n}from"./vendor.b0dde714.js";const u={},c=f("返回列表"),m=f("打印"),p=n("div",null,"您提交的内容有如下错误：",-1),_=n("div",null,[f(" 您的账户已被冻结 "),n("a",{href:"###"},"打印")],-1),x=f("返回修改");var y=a(u,[["render",function(a,f){const n=r,u=i("el-button"),y=t,b=e;return o(),d("div",null,[s(n,{title:"处理结果",content:"Result"}),s(b,{title:"成功"},{default:l((()=>[s(y,{type:"success",title:"提交成功",desc:"提交结果页用于反馈一系列操作任务的处理结果。"},{default:l((()=>[s(u,{type:"primary"},{default:l((()=>[c])),_:1}),s(u,null,{default:l((()=>[m])),_:1})])),_:1})])),_:1}),s(b,{title:"失败"},{default:l((()=>[s(y,{type:"error",title:"提交失败",desc:"灰色额外区域可以显示一些补充的信息。请核对并修改以下信息后，再重新提交。"},{extra:l((()=>[p,_])),default:l((()=>[s(u,{type:"primary"},{default:l((()=>[x])),_:1})])),_:1})])),_:1})])}]]);export{y as default};
