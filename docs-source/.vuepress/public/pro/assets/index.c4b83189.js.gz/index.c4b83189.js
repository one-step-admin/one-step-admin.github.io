
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a,u as e,g as s}from"./index.091d1180.js";import{o,k as t,$ as n,Y as r,u as d,s as l,z as p,t as c,x as i,A as u,a1 as m,a2 as f,a3 as g,m as y,C as b}from"./vendor.b0dde714.js";const h={class:"copyright"},_=["href"],v={key:1},k=n(" All Rights Reserved ");var w=a({setup(a){const s=e();return(a,e)=>(o(),t("footer",h,[n(" Copyright © "+r(d(s).copyright.dates)+" ",1),d(s).copyright.website?(o(),t("a",{key:0,href:d(s).copyright.website,target:"_blank",rel:"noopener"},r(d(s).copyright.company)+",",9,_)):(o(),t("span",v,r(d(s).copyright.company)+",",1)),k]))}},[["__scopeId","data-v-7586fb9c"]]);var x=a({setup(a){const{proxy:h}=b(),_=e(),v=l((()=>s()));function k(a){h.$i18n.locale=a,_.setDefaultLang(a)}return(a,e)=>{const s=p("el-dropdown-item"),l=p("el-dropdown-menu"),b=p("el-dropdown");return d(_).topbar.enableI18n?(o(),c(b,{key:0,class:"language-container",size:"default",onCommand:k},{dropdown:i((()=>[u(l,null,{default:i((()=>[(o(!0),t(f,null,m(d(v),((a,e)=>(o(),c(s,{key:e,disabled:d(_).app.defaultLang===a.name,command:a.name},{default:i((()=>[n(r(a.labelName),1)])),_:2},1032,["disabled","command"])))),128))])),_:1})])),default:i((()=>[g(a.$slots,"default",{},void 0,!0)])),_:3})):y("v-if",!0)}}},[["__scopeId","data-v-5d35ff72"]]);export{x as _,w as a};
