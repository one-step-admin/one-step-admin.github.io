
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as t}from"./index.7ae327c0.js";import{b$ as e,c as a,g as s,w as n,o as i,a as o,t as r,i as l,y as c}from"./index.89c4a536.js";import{E as d}from"./el-button.ee77ba8f.js";import{_ as f}from"./index.60634e19.js";/* empty css                */import"./index.0dfe2aba.js";import"./index.a744c982.js";const u=c("切换"),m=c("清空"),x={setup(c){const x=e();function p(){x.setText("热门"==x.text?"促销":"热门")}function b(){x.setText()}return(e,c)=>{const j=f,_=d,g=t;return i(),a("div",null,[s(j,{title:"文字标记",content:"搭配 Pinia 可实现动态设置。请控制文字展示长度，避免导航标记覆盖导航标题"}),s(g,null,{default:n((()=>[o("div",null,"当前 badge 值：'"+r(l(x).text)+"'",1),s(_,{onClick:p},{default:n((()=>[u])),_:1}),s(_,{onClick:b},{default:n((()=>[m])),_:1})])),_:1})])}}};export{x as default};
