
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a,u as e,n as s,c as t,y as o,t as n,h as r,b as l,C as d,D as p,i,w as c,e as u,F as m,G as f,H as y,j as g}from"./index.05e4ed9f.js";import{E as b,a as h,b as _}from"./el-dropdown-item.7564197a.js";import"./el-button.a01942a9.js";import"./el-popper.f565a276.js";const v={class:"copyright"},j=["href"],k={key:1},w=o(" All Rights Reserved ");var C=a({setup(a){const l=e();return(a,e)=>(s(),t("footer",v,[o(" Copyright © "+n(r(l).copyright.dates)+" ",1),r(l).copyright.website?(s(),t("a",{key:0,href:r(l).copyright.website,target:"_blank",rel:"noopener"},n(r(l).copyright.company)+",",9,j)):(s(),t("span",k,n(r(l).copyright.company)+",",1)),w]))}},[["__scopeId","data-v-21d46e6a"]]);var I=a({setup(a){const v=e(),{locale:j}=l(),k=d((()=>p()));function w(a){j.value=a,v.setDefaultLang(a)}return(a,e)=>{const l=b,d=h,p=_;return r(v).topbar.enableI18n?(s(),i(p,{key:0,class:"language-container",size:"default",onCommand:w},{dropdown:c((()=>[u(d,null,{default:c((()=>[(s(!0),t(f,null,m(r(k),((a,e)=>(s(),i(l,{key:e,disabled:r(v).app.defaultLang===a.name,command:a.name},{default:c((()=>[o(n(a.labelName),1)])),_:2},1032,["disabled","command"])))),128))])),_:1})])),default:c((()=>[y(a.$slots,"default",{},void 0,!0)])),_:3})):g("v-if",!0)}}},[["__scopeId","data-v-ac136df8"]]);export{I as _,C as a};
