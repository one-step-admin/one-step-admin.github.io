
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as a,E as e,c as s,g as t,w as o,o as r,G as i,F as l,a as d,p as m,l as f,y as n}from"./index.89c4a536.js";import{E as c}from"./el-row.589e4137.js";import{E as p}from"./el-col.1980009e.js";import{E as u}from"./el-card.de1888be.js";import{E as j}from"./el-button.ee77ba8f.js";import{E as v}from"./el-avatar.fc427089.js";/* empty css                */import{_}from"./index.2a4f1e1c.js";import{_ as b}from"./index.60634e19.js";import"./typescript.f55dff19.js";import"./index.0dfe2aba.js";import"./index.a744c982.js";const x={},y={class:"content"},E={class:"item"},g=(a=>(m("data-v-128a0f36"),a=a(),f(),a))((()=>d("div",{class:"item"},[d("div",{class:"name"},"Hooray"),d("div",{class:"intro"},"前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用。前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用")],-1))),w={class:"action-bar"},H=n("操作一"),h=n("操作二");var W=a(x,[["render",function(a,m){const f=b,n=_,x=e,W=v,k=j,z=u,F=p,G=c;return r(),s("div",null,[t(f,{title:"卡片列表",content:"卡片类型的列表，配合栅格实现响应式布局。"}),t(G,{gutter:20,style:{margin:"0 10px"}},{default:o((()=>[(r(),s(i,null,l(12,((a,e)=>t(F,{key:e,lg:6,md:8,sm:12},{default:o((()=>[t(z,{shadow:"hover",class:"action-card"},{default:o((()=>[d("div",y,[d("div",E,[t(W,{size:"medium"},{default:o((()=>[t(x,null,{default:o((()=>[t(n,{name:"ep:user-filled"})])),_:1})])),_:1})]),g]),d("div",w,[t(k,{type:"text"},{default:o((()=>[H])),_:1}),t(k,{type:"text"},{default:o((()=>[h])),_:1})])])),_:1})])),_:2},1024))),64))])),_:1})])}],["__scopeId","data-v-128a0f36"]]);export{W as default};
