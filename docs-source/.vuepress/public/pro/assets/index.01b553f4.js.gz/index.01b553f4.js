
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.fef54795.js";import{_ as t}from"./index.a0325b20.js";import{_ as a}from"./index.b11652ae.js";import{_ as r}from"./index.8d8a4cfe.js";import{k as s,A as l,x as d,z as i,o,$ as f,l as n}from"./vendor.b0dde714.js";const u={},m=f("返回列表"),p=f("打印"),_=n("div",null,"您提交的内容有如下错误：",-1),c=n("div",null,[f(" 您的账户已被冻结 "),n("a",{href:"###"},"打印")],-1),x=f("返回修改");var y=r(u,[["render",function(r,f){const n=a,u=i("el-button"),y=t,j=e;return o(),s("div",null,[l(n,{title:"处理结果",content:"Result"}),l(j,{title:"成功"},{default:d((()=>[l(y,{type:"success",title:"提交成功",desc:"提交结果页用于反馈一系列操作任务的处理结果。"},{default:d((()=>[l(u,{type:"primary"},{default:d((()=>[m])),_:1}),l(u,null,{default:d((()=>[p])),_:1})])),_:1})])),_:1}),l(j,{title:"失败"},{default:d((()=>[l(y,{type:"error",title:"提交失败",desc:"灰色额外区域可以显示一些补充的信息。请核对并修改以下信息后，再重新提交。"},{extra:d((()=>[_,c])),default:d((()=>[l(u,{type:"primary"},{default:d((()=>[x])),_:1})])),_:1})])),_:1})])}]]);export{y as default};
