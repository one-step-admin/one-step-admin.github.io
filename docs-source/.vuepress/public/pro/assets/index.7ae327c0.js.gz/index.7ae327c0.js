
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{o as e,c as a,a as t,_ as s,r as l,t as i,k as o,H as n,g as r,w as c,a1 as p,ab as d,E as u}from"./index.89c4a536.js";/* empty css                */const v={preserveAspectRatio:"xMidYMid meet",viewBox:"0 0 1024 1024",width:"1em",height:"1em"},f=[t("path",{fill:"currentColor",d:"M831.872 340.864L512 652.672L192.128 340.864a30.592 30.592 0 0 0-42.752 0a29.12 29.12 0 0 0 0 41.6L489.664 714.24a32 32 0 0 0 44.672 0l340.288-331.712a29.12 29.12 0 0 0 0-41.728a30.592 30.592 0 0 0-42.752 0z"},null,-1)];var h={name:"ep-arrow-down",render:function(t,s){return e(),a("svg",v,f)}};const g={key:0,class:"title-container"};var m=s({props:{title:{type:String,default:""},collaspe:{type:Boolean,default:!1},height:{type:String,default:""}},setup(t){const s=l(t.collaspe);function v(){s.value=!1}return(l,f)=>{const m=h,y=u;return e(),a("div",{class:p({"page-main":!0,"is-collaspe":s.value}),style:d({height:s.value?t.height:""})},[t.title?(e(),a("div",g,i(t.title),1)):o("v-if",!0),n(l.$slots,"default",{},void 0,!0),s.value?(e(),a("div",{key:1,class:"collaspe",title:"展开",onClick:v},[r(y,null,{default:c((()=>[r(m)])),_:1})])):o("v-if",!0)],6)}}},[["__scopeId","data-v-e230a51a"]]);export{m as _};
