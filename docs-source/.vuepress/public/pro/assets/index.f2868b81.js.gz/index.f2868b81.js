
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a}from"./index.9c1fa942.js";import{_ as t}from"./index.abd93cee.js";import{_ as i,c as s,e,w as n,n as d,p as l,k as o,f as c}from"./index.05e4ed9f.js";/* empty css                */import"./index.dd2c42e8.js";const r={},m=a=>(l("data-v-09535066"),a=a(),o(),a),p=m((()=>c("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),f=m((()=>c("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),_=m((()=>c("p",{class:"digital-7"},"Fantastic-admin",-1))),g=m((()=>c("p",{class:"digital-7"},"1234567890,.",-1))),u=m((()=>c("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),j=m((()=>c("p",{class:"digital-7_mono"},"1234567890,.",-1)));var x=i(r,[["render",function(i,l){const o=t,c=a;return d(),s("div",null,[e(o,{title:"自定义字体"},{content:n((()=>[p,f])),_:1}),e(c,{title:"Digital 7"},{default:n((()=>[_,g])),_:1}),e(c,{title:"Digital 7（等宽）"},{default:n((()=>[u,j])),_:1})])}],["__scopeId","data-v-09535066"]]);export{x as default};
