
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e,E as t,c as a,g as n,w as o,o as r,a as s,y as i}from"./index.89c4a536.js";import{E as l}from"./el-button.ee77ba8f.js";/* empty css                */import{_ as d}from"./index.2a4f1e1c.js";import{_ as f}from"./index.60634e19.js";import"./index.0dfe2aba.js";import"./index.a744c982.js";const c={},m=s("p",null,"提供两块插槽：",-1),u=s("p",null,"一块是 content 区域插槽，一块是右侧区域",-1),p=i(" 返回 ");var j=e(c,[["render",function(e,s){const i=f,c=d,j=t,x=l;return r(),a("div",null,[n(i,{title:"页头",content:"PageHeader"}),n(i,{title:"页面标题"},{content:o((()=>[m,u])),default:o((()=>[n(x,{round:""},{icon:o((()=>[n(j,null,{default:o((()=>[n(c,{name:"ep:arrow-left"})])),_:1})])),default:o((()=>[p])),_:1})])),_:1})])}]]);export{j as default};
