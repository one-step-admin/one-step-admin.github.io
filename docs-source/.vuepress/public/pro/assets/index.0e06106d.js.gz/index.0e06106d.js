
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as e}from"./index.15becada.js";import{_ as l,c as m,b as o,w as a,n as t}from"./index.0a5e3bc2.js";import{E as d}from"./el-input-number.d220782b.js";import"./el-input.3dbe719d.js";import{_ as n}from"./index.872bc773.js";/* empty css                */import"./index.5fef9d7d.js";import"./isNil.aac33454.js";import"./index2.32130bcb.js";import"./event2.3b438cf1.js";import"./index2.6a73fda0.js";import"./index2.fa2fe4ab.js";import"./index2.f37a6952.js";import"./error2.1d524120.js";import"./arrow-up.72ffa464.js";import"./arrow-down.2c5054c4.js";import"./plus.d444f507.js";import"./typescript2.7477ece2.js";import"./event2.27558ffe.js";import"./index2.0c75c32d.js";import"./el-alert.2d5c6d9e.js";import"./el-link.080e9c24.js";var i=l({data:()=>({num:1,num2:1,num3:5,num4:1,num5:1})},[["render",function(l,i,s,u,r,p){const c=n,f=d,j=e;return t(),m("div",null,[o(c),o(j,{title:"基础用法",class:"demo"},{default:a((()=>[o(f,{modelValue:r.num,"onUpdate:modelValue":i[0]||(i[0]=e=>r.num=e),min:1,max:10,label:"描述文字"},null,8,["modelValue"])])),_:1}),o(j,{title:"禁用状态",class:"demo"},{default:a((()=>[o(f,{modelValue:r.num2,"onUpdate:modelValue":i[1]||(i[1]=e=>r.num2=e),disabled:!0},null,8,["modelValue"])])),_:1}),o(j,{title:"步数",class:"demo"},{default:a((()=>[o(f,{modelValue:r.num3,"onUpdate:modelValue":i[2]||(i[2]=e=>r.num3=e),step:2},null,8,["modelValue"])])),_:1}),o(j,{title:"精度",class:"demo"},{default:a((()=>[o(f,{modelValue:r.num4,"onUpdate:modelValue":i[3]||(i[3]=e=>r.num4=e),precision:2,step:.1,max:10},null,8,["modelValue","step"])])),_:1}),o(j,{title:"按钮位置",class:"demo"},{default:a((()=>[o(f,{modelValue:r.num5,"onUpdate:modelValue":i[4]||(i[4]=e=>r.num5=e),"controls-position":"right",min:1,max:10},null,8,["modelValue"])])),_:1})])}]]);export{i as default};
