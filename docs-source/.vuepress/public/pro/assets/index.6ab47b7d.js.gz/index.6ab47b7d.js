
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as t}from"./index.15becada.js";import{c0 as e,c as a,b as s,w as n,n as i,e as o,t as f,f as d,y as r}from"./index.0a5e3bc2.js";import{E as l}from"./el-button.2fada245.js";import{_ as c}from"./index.7bc6f31f.js";/* empty css                */import"./index.5fef9d7d.js";import"./index2.f37a6952.js";import"./index2.2a4e9295.js";import"./index2.fa2fe4ab.js";const m=r("切换"),u=r("清空"),x={setup(r){const x=e();function p(){x.setText("热门"==x.text?"促销":"热门")}function b(){x.setText()}return(e,r)=>{const j=c,_=l,k=t;return i(),a("div",null,[s(j,{title:"文字标记",content:"搭配 Pinia 可实现动态设置。请控制文字展示长度，避免导航标记覆盖导航标题"}),s(k,null,{default:n((()=>[o("div",null,"当前 badge 值：'"+f(d(x).text)+"'",1),s(_,{onClick:p},{default:n((()=>[m])),_:1}),s(_,{onClick:b},{default:n((()=>[u])),_:1})])),_:1})])}}};export{x as default};
