
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a}from"./index.e5c277f9.js";import{_ as t}from"./index.e3b25878.js";import{_ as i}from"./index.9dc02013.js";import{k as s,A as l,x as o,o as n,p as e,q as d,l as r}from"./vendor.6ae38f98.js";const m={},c=a=>(e("data-v-09535066"),a=a(),d(),a),p=c((()=>r("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),f=c((()=>r("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),_=c((()=>r("p",{class:"digital-7"},"Fantastic-admin",-1))),g=c((()=>r("p",{class:"digital-7"},"1234567890,.",-1))),u=c((()=>r("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),v=c((()=>r("p",{class:"digital-7_mono"},"1234567890,.",-1)));var x=i(m,[["render",function(i,e){const d=t,r=a;return n(),s("div",null,[l(d,{title:"自定义字体"},{content:o((()=>[p,f])),_:1}),l(r,{title:"Digital 7"},{default:o((()=>[_,g])),_:1}),l(r,{title:"Digital 7（等宽）"},{default:o((()=>[u,v])),_:1})])}],["__scopeId","data-v-09535066"]]);export{x as default};
