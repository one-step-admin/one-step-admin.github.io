
/**
 * 由 Fantastic-admin-discovery 提供技术支持
 * https://hooray.gitee.io/fantastic-admin-discovery/
 * Powered by Fantastic-admin-discovery
 * https://hooray.github.io/fantastic-admin-discovery/
 */
    
import{_ as n}from"./index.e01cfd04.js";import{_}from"./plugin-vue_export-helper.5a098b48.js";import{a4 as c,o as i,I as r,l as d,j as p,J as e,O as l,P as h,T as t}from"./vendor.6b4522dc.js";const u=a=>(l("data-v-03a26098"),a=a(),h(),a),m={class:"empty-container"},v=u(()=>e("div",{style:{"margin-bottom":"5px"}},[t("\u8FD9\u662F\u4E00\u6B3E\u5177\u5907"),e("b",{class:"text-emphasis"},"\u5168\u65B0\u4EA4\u4E92\u65B9\u5F0F"),t("\u7684\u4E2D\u540E\u53F0\u6846\u67B6\uFF0C\u4E3A\u4E86"),e("b",null,"\u63D0\u9AD8\u4F7F\u7528\u4EBA\u5458\u7684\u64CD\u4F5C\u6548\u7387"),t("\u4E0E"),e("b",null,"\u51CF\u8F7B\u5F00\u53D1\u4EBA\u5458\u7684\u5F00\u53D1\u6210\u672C"),t("\u800C\u751F\u3002")],-1)),f=t("\u5982\u679C\u4F60\u9700\u8981\u7684\u662F\u901A\u7528\u7684\u4E2D\u540E\u53F0\u6846\u67B6\uFF0C\u53EF\u4EE5\u4E86\u89E3\u4E0B "),x=["href"],g=t(" \uFF0C\u5B83\u540C\u6837\u662F\u4E00\u6B3E\u975E\u5E38\u4F18\u79C0\u7684\u4E2D\u540E\u53F0\u6846\u67B6\u3002"),b={setup(a){const o=c(location.href);return(y,I)=>{const s=n;return i(),r("div",m,[d(s,{title:"Fantastic-admin-discovery\uFF08\u63A2\u7D22\u7248\uFF09",class:"header"},{content:p(()=>[e("div",null,[v,e("div",null,[f,e("a",{href:`https://hooray.${o.value.includes("gitee")?"gitee":"github"}.io/fantastic-admin`,target:"_blank"},"Fantastic-admin",8,x),g])])]),_:1})])}}};var N=_(b,[["__scopeId","data-v-03a26098"]]);export{N as default};
