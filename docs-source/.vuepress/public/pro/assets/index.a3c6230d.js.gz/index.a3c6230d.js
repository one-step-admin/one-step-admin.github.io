
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a,E as e,c as s,e as t,w as o,n as r,G as i,F as d,f as l,p as f,k as m,y as c}from"./index.05e4ed9f.js";import{E as n}from"./el-row.5e74fbc9.js";import{E as p}from"./el-col.8e8a833a.js";import{E as u}from"./el-card.76137b02.js";import{E as b}from"./el-button.a01942a9.js";import{E as j}from"./el-avatar.f8101b82.js";/* empty css                */import{_ as v}from"./index.dd2c42e8.js";import{_}from"./index.abd93cee.js";import"./typescript.14beffb5.js";import"./index.48c8fc0e.js";import"./index.aa8c6f3e.js";const x={},y={class:"content"},E={class:"item"},g=(a=>(f("data-v-128a0f36"),a=a(),m(),a))((()=>l("div",{class:"item"},[l("div",{class:"name"},"Hooray"),l("div",{class:"intro"},"前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用。前端开发工程师，10年+开发经验，可开发 Web / H5 / 小程序 等应用")],-1))),w={class:"action-bar"},H=c("操作一"),h=c("操作二");var k=a(x,[["render",function(a,f){const m=_,c=v,x=e,k=j,W=b,z=u,F=p,G=n;return r(),s("div",null,[t(m,{title:"卡片列表",content:"卡片类型的列表，配合栅格实现响应式布局。"}),t(G,{gutter:20,style:{margin:"0 10px"}},{default:o((()=>[(r(),s(i,null,d(12,((a,e)=>t(F,{key:e,lg:6,md:8,sm:12},{default:o((()=>[t(z,{shadow:"hover",class:"action-card"},{default:o((()=>[l("div",y,[l("div",E,[t(k,{size:"medium"},{default:o((()=>[t(x,null,{default:o((()=>[t(c,{name:"ep:user-filled"})])),_:1})])),_:1})]),g]),l("div",w,[t(W,{type:"text"},{default:o((()=>[H])),_:1}),t(W,{type:"text"},{default:o((()=>[h])),_:1})])])),_:1})])),_:2},1024))),64))])),_:1})])}],["__scopeId","data-v-128a0f36"]]);export{k as default};
