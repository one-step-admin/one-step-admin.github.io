
/**
 * 由 One-step-admin 提供技术支持
 * Powered by One-step-admin
 * https://one-step-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/one-step-admin
 * Github https://github.com/hooray/one-step-admin
 */
    
import{_ as a}from"./index.7ae327c0.js";import{_ as t}from"./index.60634e19.js";import{_ as i,c as s,g as l,w as n,o,p as e,l as d,a as c}from"./index.89c4a536.js";/* empty css                */const r={},m=a=>(e("data-v-09535066"),a=a(),d(),a),p=m((()=>c("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),_=m((()=>c("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),f=m((()=>c("p",{class:"digital-7"},"Fantastic-admin",-1))),g=m((()=>c("p",{class:"digital-7"},"1234567890,.",-1))),u=m((()=>c("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),j=m((()=>c("p",{class:"digital-7_mono"},"1234567890,.",-1)));var v=i(r,[["render",function(i,e){const d=t,c=a;return o(),s("div",null,[l(d,{title:"自定义字体"},{content:n((()=>[p,_])),_:1}),l(c,{title:"Digital 7"},{default:n((()=>[f,g])),_:1}),l(c,{title:"Digital 7（等宽）"},{default:n((()=>[u,j])),_:1})])}],["__scopeId","data-v-09535066"]]);export{v as default};
