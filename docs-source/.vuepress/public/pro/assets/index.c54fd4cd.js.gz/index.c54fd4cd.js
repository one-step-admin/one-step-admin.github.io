
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.84a18d1d.js";import{_ as l}from"./index.4fc47fa2.js";import{_ as a,c as d,b as u,w as t,m as o,n as m}from"./index.93ad63e3.js";var s=a({data:()=>({value:!0,value1:!0,value2:!0,value3:!1})},[["render",function(a,s,i,n,v,r){const c=l,f=o("el-switch"),V=e;return m(),d("div",null,[u(c),u(V,{title:"基础用法",class:"demo"},{default:t((()=>[u(f,{modelValue:v.value,"onUpdate:modelValue":s[0]||(s[0]=e=>v.value=e),"active-color":"#13ce66","inactive-color":"#ff4949"},null,8,["modelValue"])])),_:1}),u(V,{title:"文字描述",class:"demo"},{default:t((()=>[u(f,{modelValue:v.value1,"onUpdate:modelValue":s[1]||(s[1]=e=>v.value1=e),"active-text":"按月付费","inactive-text":"按年付费"},null,8,["modelValue"])])),_:1}),u(V,{title:"禁用状态",class:"demo"},{default:t((()=>[u(f,{modelValue:v.value2,"onUpdate:modelValue":s[2]||(s[2]=e=>v.value2=e),disabled:"",style:{"margin-right":"10px"}},null,8,["modelValue"]),u(f,{modelValue:v.value3,"onUpdate:modelValue":s[3]||(s[3]=e=>v.value3=e),disabled:""},null,8,["modelValue"])])),_:1})])}]]);export{s as default};
