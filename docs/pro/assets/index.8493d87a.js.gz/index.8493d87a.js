
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as u}from"./index.0e432c25.js";import{_ as c}from"./index.418d3b50.js";import{x as a,an as f,j as m,A as i,z as o,o as g,V as v,k as s,$ as d}from"./vendor.5ed2e184.js";const V={data(){return{dialogVisible:!1}}},x=d("\u70B9\u51FB\u6253\u5F00 Dialog"),b=s("div",null," \u6309\u4F4F\u6211\u8FDB\u884C\u62D6\u52A8 ",-1),k=s("span",null,"\u8FD9\u662F\u4E00\u6BB5\u4FE1\u606F",-1),C={class:"dialog-footer"},j=d("\u53D6 \u6D88"),w=d("\u786E \u5B9A");function y(B,e,D,N,t,$){const n=a("el-button"),r=a("el-dialog"),_=u,p=f("drag");return g(),m("div",null,[i(_,null,{default:o(()=>[i(n,{type:"text",onClick:e[0]||(e[0]=l=>t.dialogVisible=!0)},{default:o(()=>[x]),_:1}),v(s("div",null,[i(r,{modelValue:t.dialogVisible,"onUpdate:modelValue":e[3]||(e[3]=l=>t.dialogVisible=l),width:"30%"},{title:o(()=>[b]),footer:o(()=>[s("span",C,[i(n,{onClick:e[1]||(e[1]=l=>t.dialogVisible=!1)},{default:o(()=>[j]),_:1}),i(n,{type:"primary",onClick:e[2]||(e[2]=l=>t.dialogVisible=!1)},{default:o(()=>[w]),_:1})])]),default:o(()=>[k]),_:1},8,["modelValue"])],512),[[p]])]),_:1})])}var E=c(V,[["render",y]]);export{E as default};
