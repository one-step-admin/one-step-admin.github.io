
/**
 * 由 Fantastic-admin 提供技术支持
 * https://hooray.gitee.io/fantastic-admin/
 * Powered by Fantastic-admin
 * https://hooray.github.io/fantastic-admin/
 */
    
import{_ as s}from"./index.b92ebba1.js";import{_ as i}from"./index.a4d9ae54.js";import{_ as c}from"./logo.96f1da49.js";import{_ as r}from"./plugin-vue_export-helper.5a098b48.js";import{G as l,l as e,j as o,o as d,R as _,H as n}from"./vendor.e2abc40b.js";const p={},m=_(" PageMain \u662F\u6700\u5E38\u7528\u7684\u9875\u9762\u7EC4\u4EF6\uFF0C\u51E0\u4E4E\u6240\u6709\u9875\u9762\u90FD\u4F1A\u4F7F\u7528\u5230 "),u=_(" \u8FD9\u91CC\u653E\u9875\u9762\u5185\u5BB9 "),f=n("h1",null,"Fantastic-admin",-1),h=n("img",{src:c},null,-1),g=n("p",null,"\u8FD9\u662F\u4E00\u6B3E\u5F00\u7BB1\u5373\u7528\u7684\u4E2D\u540E\u53F0\u6846\u67B6\uFF0C\u540C\u65F6\u5B83\u4E5F\u7ECF\u5386\u8FC7\u6570\u5341\u4E2A\u771F\u5B9E\u9879\u76EE\u7684\u6280\u672F\u6C89\u6DC0\uFF0C\u786E\u4FDD\u6846\u67B6\u5728\u5F00\u53D1\u4E2D\u53EF\u843D\u5730\u3001\u53EF\u4F7F\u7528\u3001\u53EF\u7EF4\u62A4",-1);function x(b,j){const a=i,t=s;return d(),l("div",null,[e(a,{title:"\u5185\u5BB9\u5757",content:"PageMain"}),e(t,null,{default:o(()=>[m]),_:1}),e(t,{title:"\u4F60\u53EF\u4EE5\u8BBE\u7F6E\u4E00\u4E2A\u81EA\u5B9A\u4E49\u7684\u6807\u9898"},{default:o(()=>[u]),_:1}),e(t,{title:"\u5E26\u5C55\u5F00\u529F\u80FD",collaspe:"",height:"200px"},{default:o(()=>[f,h,g]),_:1})])}var M=r(p,[["render",x]]);export{M as default};
