
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.8346cdbe.js";import{_ as l}from"./index.7597e0bd.js";import{_ as a,c as u,b as d,w as o,m as t,n as s}from"./index.d26282ba.js";var m=a({data:()=>({value1:null,value2:null,value3:3.7})},[["render",function(a,m,n,r,i,v){const c=l,f=t("el-rate"),V=e;return s(),u("div",null,[d(c),d(V,{title:"基础用法",class:"demo"},{default:o((()=>[d(f,{modelValue:i.value1,"onUpdate:modelValue":m[0]||(m[0]=e=>i.value1=e)},null,8,["modelValue"])])),_:1}),d(V,{title:"辅助文字",class:"demo"},{default:o((()=>[d(f,{modelValue:i.value2,"onUpdate:modelValue":m[1]||(m[1]=e=>i.value2=e),"show-text":"",texts:["极差","差","一般","好","极好"]},null,8,["modelValue"])])),_:1}),d(V,{title:"只读",class:"demo"},{default:o((()=>[d(f,{modelValue:i.value3,"onUpdate:modelValue":m[2]||(m[2]=e=>i.value3=e),disabled:"","show-score":"","text-color":"#ff9900","score-template":"{value}"},null,8,["modelValue"])])),_:1})])}]]);export{m as default};
