
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a}from"./index.e5c277f9.js";import{_ as n}from"./index.a32c7679.js";import{_ as e}from"./index.e3b25878.js";import{_ as o}from"./index.9dc02013.js";import{k as i,A as d,x as s,z as t,o as l,$ as r}from"./vendor.6ae38f98.js";const m={methods:{open(a){window.open(a,"top")}}},c=r("SVG-Loaders 官网");var g=o(m,[["render",function(o,r,m,g,p,f){const u=t("el-button"),_=e,v=n,b=a;return l(),i("div",null,[d(_,{title:"SVG 动画",content:"svg 文件从 SVG-Loaders 中提取，需要注意，svg 均为白色，需要增加底色才能看到效果。如需封装成加载组件，可参考 SpinkitLoading 组件"},{default:s((()=>[d(u,{icon:"el-icon-link",onClick:r[0]||(r[0]=a=>f.open("http://samherbert.net/svg-loaders/"))},{default:s((()=>[c])),_:1})])),_:1}),d(b,{style:{"background-color":"#34495e"}},{default:s((()=>[d(v,{name:"loading-audio"}),d(v,{name:"loading-ball-triangle"}),d(v,{name:"loading-bars"}),d(v,{name:"loading-circles"}),d(v,{name:"loading-grid"}),d(v,{name:"loading-hearts"}),d(v,{name:"loading-oval"}),d(v,{name:"loading-puff"}),d(v,{name:"loading-rings"}),d(v,{name:"loading-spinning-circles"}),d(v,{name:"loading-tail-spin"}),d(v,{name:"loading-three-dots"})])),_:1})])}],["__scopeId","data-v-3c13ccc0"]]);export{g as default};
