
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as f}from"./index.ef5f4349.js";import{_ as m}from"./index.5c755cb6.js";import{k as d,A as l,x as o,z as r,ap as g,o as _,T as v,l as n,$ as a}from"./vendor.18c32348.js";const V={data(){return{dialogVisible:!1}}},x=a("\u70B9\u51FB\u6253\u5F00 Dialog"),b=n("div",null," \u6309\u4F4F\u6211\u8FDB\u884C\u62D6\u52A8 ",-1),k=n("span",null,"\u8FD9\u662F\u4E00\u6BB5\u4FE1\u606F",-1),C={class:"dialog-footer"},j=a("\u53D6 \u6D88"),w=a("\u786E \u5B9A");function y(B,e,D,N,t,$){const s=r("el-button"),p=r("el-dialog"),u=f,c=g("drag");return _(),d("div",null,[l(u,null,{default:o(()=>[l(s,{type:"text",onClick:e[0]||(e[0]=i=>t.dialogVisible=!0)},{default:o(()=>[x]),_:1}),v((_(),d("div",null,[l(p,{modelValue:t.dialogVisible,"onUpdate:modelValue":e[3]||(e[3]=i=>t.dialogVisible=i),width:"30%"},{title:o(()=>[b]),footer:o(()=>[n("span",C,[l(s,{onClick:e[1]||(e[1]=i=>t.dialogVisible=!1)},{default:o(()=>[j]),_:1}),l(s,{type:"primary",onClick:e[2]||(e[2]=i=>t.dialogVisible=!1)},{default:o(()=>[w]),_:1})])]),default:o(()=>[k]),_:1},8,["modelValue"])])),[[c]])]),_:1})])}var A=m(V,[["render",y]]);export{A as default};
