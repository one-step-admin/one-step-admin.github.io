
/**
 * 由 Fantastic-admin-discovery 提供技术支持
 * https://hooray.gitee.io/fantastic-admin-discovery/
 * Powered by Fantastic-admin-discovery
 * https://hooray.github.io/fantastic-admin-discovery/
 */
    
import{_ as i}from"./index.7fb28950.js";import r from"./index.f4bb6020.js";import{_ as d}from"./plugin-vue_export-helper.5a098b48.js";import{a1 as l,o,I as t,J as p,U as _,l as a,M as c}from"./vendor.6b4522dc.js";import"./index.13449989.js";import"./index.688b493d.js";import"./index.fe95d298.js";const m={class:"topbar-container","data-fixed-calc-width":""},b={class:"left-box"},u=l({name:"Topbar"});function f(g){return(e,s)=>{const n=i;return o(),t("div",m,[p("div",b,[["side","head","single"].includes(e.$store.state.settings.menuMode)&&e.$store.state.settings.enableSidebarCollapse?(o(),t("div",{key:0,class:_(["sidebar-collapse",{"is-collapse":e.$store.state.settings.sidebarCollapse}]),onClick:s[0]||(s[0]=x=>e.$store.commit("settings/toggleSidebarCollapse"))},[a(n,{name:"toolbar-collapse"})],2)):c("v-if",!0)]),a(r)])}}const v=Object.assign(u,{setup:f});var M=d(v,[["__scopeId","data-v-67b383d3"]]);export{M as default};
