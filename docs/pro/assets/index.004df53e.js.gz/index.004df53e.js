
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a}from"./index.e4264495.js";import{_ as t}from"./index.f15ab100.js";import{_ as i,c as s,g as l,w as n,o,p as e,l as d,a as r}from"./index.b046d3e8.js";/* empty css                */const c={},m=a=>(e("data-v-09535066"),a=a(),d(),a),p=m((()=>r("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),_=m((()=>r("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),f=m((()=>r("p",{class:"digital-7"},"Fantastic-admin",-1))),g=m((()=>r("p",{class:"digital-7"},"1234567890,.",-1))),u=m((()=>r("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),b=m((()=>r("p",{class:"digital-7_mono"},"1234567890,.",-1)));var j=i(c,[["render",function(i,e){const d=t,r=a;return o(),s("div",null,[l(d,{title:"自定义字体"},{content:n((()=>[p,_])),_:1}),l(r,{title:"Digital 7"},{default:n((()=>[f,g])),_:1}),l(r,{title:"Digital 7（等宽）"},{default:n((()=>[u,b])),_:1})])}],["__scopeId","data-v-09535066"]]);export{j as default};
