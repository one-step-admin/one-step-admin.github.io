
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as u,u as i,g as C}from"./index.61ee47b7.js";import{o,k as s,$ as d,Y as r,u as e,t as k,x as l,y as m,z as _,A as b,a1 as w,a2 as S,a3 as $,m as I,C as L}from"./vendor.f7e26336.js";const N={class:"copyright"},B=["href"],D={key:1},V=d(" All Rights Reserved "),j={setup(g){const t=i();return(n,p)=>(o(),s("footer",N,[d(" Copyright \xA9 "+r(e(t).copyrightDates)+" ",1),e(t).copyrightWebsite?(o(),s("a",{key:0,href:e(t).copyrightWebsite,target:"_blank",rel:"noopener"},r(e(t).copyrightCompany)+",",9,B)):(o(),s("span",D,r(e(t).copyrightCompany)+",",1)),V]))}};var W=u(j,[["__scopeId","data-v-439d53fe"]]);const z={setup(g){const{proxy:t}=L(),n=i(),p=k(()=>C());function f(a){t.$i18n.locale=a,n.setDefaultLang(a)}return(a,A)=>{const y=l("el-dropdown-item"),h=l("el-dropdown-menu"),v=l("el-dropdown");return e(n).enableI18n?(o(),m(v,{key:0,class:"language-container",size:"default",onCommand:f},{dropdown:_(()=>[b(h,null,{default:_(()=>[(o(!0),s(S,null,w(e(p),(c,x)=>(o(),m(y,{key:x,disabled:e(n).defaultLang===c.name,command:c.name},{default:_(()=>[d(r(c.labelName),1)]),_:2},1032,["disabled","command"]))),128))]),_:1})]),default:_(()=>[$(a.$slots,"default",{},void 0,!0)]),_:3})):I("v-if",!0)}}};var F=u(z,[["__scopeId","data-v-220934e2"]]);export{F as _,W as a};
