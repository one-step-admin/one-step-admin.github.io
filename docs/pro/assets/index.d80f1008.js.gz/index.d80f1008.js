
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.538e7de7.js";import{_ as l}from"./index.d429e7e3.js";import{_ as a,c as u,b as o,w as t,m as d,n as s}from"./index.25647206.js";var m=a({data:()=>({value1:null,value2:null,value3:3.7})},[["render",function(a,m,n,r,i,v){const f=l,c=d("el-rate"),V=e;return s(),u("div",null,[o(f),o(V,{title:"基础用法",class:"demo"},{default:t((()=>[o(c,{modelValue:i.value1,"onUpdate:modelValue":m[0]||(m[0]=e=>i.value1=e)},null,8,["modelValue"])])),_:1}),o(V,{title:"辅助文字",class:"demo"},{default:t((()=>[o(c,{modelValue:i.value2,"onUpdate:modelValue":m[1]||(m[1]=e=>i.value2=e),"show-text":"",texts:["极差","差","一般","好","极好"]},null,8,["modelValue"])])),_:1}),o(V,{title:"只读",class:"demo"},{default:t((()=>[o(c,{modelValue:i.value3,"onUpdate:modelValue":m[2]||(m[2]=e=>i.value3=e),disabled:"","show-score":"","text-color":"#ff9900","score-template":"{value}"},null,8,["modelValue"])])),_:1})])}]]);export{m as default};
