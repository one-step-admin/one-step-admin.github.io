
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a}from"./index.538e7de7.js";import{_ as t}from"./index.bc6ef411.js";import{_ as i,c as s,b as l,w as n,n as e,p as d,j as o,e as c}from"./index.25647206.js";const r={},m=a=>(d("data-v-09535066"),a=a(),o(),a),p=m((()=>c("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),_=m((()=>c("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),f=m((()=>c("p",{class:"digital-7"},"Fantastic-admin",-1))),g=m((()=>c("p",{class:"digital-7"},"1234567890,.",-1))),u=m((()=>c("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),j=m((()=>c("p",{class:"digital-7_mono"},"1234567890,.",-1)));var v=i(r,[["render",function(i,d){const o=t,c=a;return e(),s("div",null,[l(o,{title:"自定义字体"},{content:n((()=>[p,_])),_:1}),l(c,{title:"Digital 7"},{default:n((()=>[f,g])),_:1}),l(c,{title:"Digital 7（等宽）"},{default:n((()=>[u,j])),_:1})])}],["__scopeId","data-v-09535066"]]);export{v as default};
