
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as m}from"./index.6234b394.js";import{_ as r}from"./index.e7c867e4.js";import{_ as d}from"./index.1c098545.js";import{x as p,j as _,A as e,z as a,o as i}from"./vendor.f0fdd3fc.js";const c={data(){return{value1:null,value2:null,value3:3.7}}};function f(v,l,x,V,o,j){const u=r,n=p("el-rate"),s=m;return i(),_("div",null,[e(u),e(s,{title:"\u57FA\u7840\u7528\u6CD5",class:"demo"},{default:a(()=>[e(n,{modelValue:o.value1,"onUpdate:modelValue":l[0]||(l[0]=t=>o.value1=t)},null,8,["modelValue"])]),_:1}),e(s,{title:"\u8F85\u52A9\u6587\u5B57",class:"demo"},{default:a(()=>[e(n,{modelValue:o.value2,"onUpdate:modelValue":l[1]||(l[1]=t=>o.value2=t),"show-text":"",texts:["\u6781\u5DEE","\u5DEE","\u4E00\u822C","\u597D","\u6781\u597D"]},null,8,["modelValue"])]),_:1}),e(s,{title:"\u53EA\u8BFB",class:"demo"},{default:a(()=>[e(n,{modelValue:o.value3,"onUpdate:modelValue":l[2]||(l[2]=t=>o.value3=t),disabled:"","show-score":"","text-color":"#ff9900","score-template":"{value}"},null,8,["modelValue"])]),_:1})])}var U=d(c,[["render",f]]);export{U as default};
