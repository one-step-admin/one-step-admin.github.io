
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
var e=Object.defineProperty,a=Object.defineProperties,r=Object.getOwnPropertyDescriptors,s=Object.getOwnPropertySymbols,t=Object.prototype.hasOwnProperty,o=Object.prototype.propertyIsEnumerable,l=(a,r,s)=>r in a?e(a,r,{enumerable:!0,configurable:!0,writable:!0,value:s}):a[r]=s;import{I as d,M as n,d as c,J as p,n as y,c as i,a1 as b,h as f,H as u,y as h,t as m,j as v,f as O,ab as j,a2 as w,L as g}from"./index.05e4ed9f.js";const S=d({header:{type:String,default:""},bodyStyle:{type:n([String,Object,Array]),default:""},shadow:{type:String,default:"always"}}),P=c(($=((e,a)=>{for(var r in a||(a={}))t.call(a,r)&&l(e,r,a[r]);if(s)for(var r of s(a))o.call(a,r)&&l(e,r,a[r]);return e})({},{name:"ElCard"}),a($,r({props:S,setup(e){const a=p("card");return(e,r)=>(y(),i("div",{class:b([f(a).b(),f(a).is(`${e.shadow}-shadow`)])},[e.$slots.header||e.header?(y(),i("div",{key:0,class:b(f(a).e("header"))},[u(e.$slots,"header",{},(()=>[h(m(e.header),1)]))],2)):v("v-if",!0),O("div",{class:b(f(a).e("body")),style:j(e.bodyStyle)},[u(e.$slots,"default")],6)],2))}}))));var $;const k=g(w(P,[["__file","/home/runner/work/element-plus/element-plus/packages/components/card/src/card.vue"]]));export{k as E};
