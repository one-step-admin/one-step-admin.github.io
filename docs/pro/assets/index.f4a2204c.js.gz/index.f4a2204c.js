
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as l}from"./index.fef54795.js";import{_ as a}from"./index.8d8a4cfe.js";import{k as e,A as i,x as o,z as d,ap as s,o as t,T as n,l as r,$ as u}from"./vendor.b0dde714.js";const f={data:()=>({dialogVisible:!1})},p=u("点击打开 Dialog"),g=r("div",null," 按住我进行拖动 ",-1),m=r("span",null,"这是一段信息",-1),V={class:"dialog-footer"},b=u("取 消"),c=u("确 定");var _=a(f,[["render",function(a,u,f,_,v,x){const k=d("el-button"),j=d("el-dialog"),y=l,C=s("drag");return t(),e("div",null,[i(y,null,{default:o((()=>[i(k,{type:"text",onClick:u[0]||(u[0]=l=>v.dialogVisible=!0)},{default:o((()=>[p])),_:1}),n((t(),e("div",null,[i(j,{modelValue:v.dialogVisible,"onUpdate:modelValue":u[3]||(u[3]=l=>v.dialogVisible=l),width:"30%"},{title:o((()=>[g])),footer:o((()=>[r("span",V,[i(k,{onClick:u[1]||(u[1]=l=>v.dialogVisible=!1)},{default:o((()=>[b])),_:1}),i(k,{type:"primary",onClick:u[2]||(u[2]=l=>v.dialogVisible=!1)},{default:o((()=>[c])),_:1})])])),default:o((()=>[m])),_:1},8,["modelValue"])])),[[C]])])),_:1})])}]]);export{_ as default};
