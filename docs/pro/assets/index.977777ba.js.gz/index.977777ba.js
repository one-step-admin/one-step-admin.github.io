
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a}from"./index.fef54795.js";import{_ as t}from"./index.b11652ae.js";import{_ as i}from"./index.8d8a4cfe.js";import{k as s,A as l,x as o,o as d,p as e,q as n,l as r}from"./vendor.b0dde714.js";const m={},p=a=>(e("data-v-09535066"),a=a(),n(),a),c=p((()=>r("p",null,"自定义字体需要下载字体文件，不建议在非英文环境中使用",-1))),f=p((()=>r("p",{style:{"margin-bottom":"0"}},"以下为框架预设字体",-1))),_=p((()=>r("p",{class:"digital-7"},"Fantastic-admin",-1))),g=p((()=>r("p",{class:"digital-7"},"1234567890,.",-1))),u=p((()=>r("p",{class:"digital-7_mono"},"Fantastic-admin",-1))),v=p((()=>r("p",{class:"digital-7_mono"},"1234567890,.",-1)));var x=i(m,[["render",function(i,e){const n=t,r=a;return d(),s("div",null,[l(n,{title:"自定义字体"},{content:o((()=>[c,f])),_:1}),l(r,{title:"Digital 7"},{default:o((()=>[_,g])),_:1}),l(r,{title:"Digital 7（等宽）"},{default:o((()=>[u,v])),_:1})])}],["__scopeId","data-v-09535066"]]);export{x as default};
