
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as i}from"./index.0e432c25.js";import{_ as c}from"./index.1daf76ce.js";import{_ as d}from"./index.418d3b50.js";import{j as p,A as _,z as s,o as l,p as r,m,k as t}from"./vendor.5ed2e184.js";const u={},e=o=>(r("data-v-09535066"),o=o(),m(),o),f=e(()=>t("p",null,"\u81EA\u5B9A\u4E49\u5B57\u4F53\u9700\u8981\u4E0B\u8F7D\u5B57\u4F53\u6587\u4EF6\uFF0C\u4E0D\u5EFA\u8BAE\u5728\u975E\u82F1\u6587\u73AF\u5883\u4E2D\u4F7F\u7528",-1)),g=e(()=>t("p",{style:{"margin-bottom":"0"}},"\u4EE5\u4E0B\u4E3A\u6846\u67B6\u9884\u8BBE\u5B57\u4F53",-1)),h=e(()=>t("p",{class:"digital-7"},"Fantastic-admin",-1)),x=e(()=>t("p",{class:"digital-7"},"1234567890,.",-1)),v=e(()=>t("p",{class:"digital-7_mono"},"Fantastic-admin",-1)),j=e(()=>t("p",{class:"digital-7_mono"},"1234567890,.",-1));function I(o,k){const n=c,a=i;return l(),p("div",null,[_(n,{title:"\u81EA\u5B9A\u4E49\u5B57\u4F53"},{content:s(()=>[f,g]),_:1}),_(a,{title:"Digital 7"},{default:s(()=>[h,x]),_:1}),_(a,{title:"Digital 7\uFF08\u7B49\u5BBD\uFF09"},{default:s(()=>[v,j]),_:1})])}var w=d(u,[["render",I],["__scopeId","data-v-09535066"]]);export{w as default};
