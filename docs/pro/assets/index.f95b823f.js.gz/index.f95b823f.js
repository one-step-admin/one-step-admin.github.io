
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as l}from"./index.8346cdbe.js";import{_ as a,c as e,b as i,w as d,m as o,aa as s,n as t,f as n,e as u,y as r}from"./index.d26282ba.js";const f={data:()=>({dialogVisible:!1})},b=r("点击打开 Dialog"),g=u("div",null," 按住我进行拖动 ",-1),c=u("span",null,"这是一段信息",-1),m={class:"dialog-footer"},p=r("取 消"),V=r("确 定");var _=a(f,[["render",function(a,r,f,_,v,x){const y=o("el-button"),k=o("el-dialog"),C=l,j=s("drag");return t(),e("div",null,[i(C,null,{default:d((()=>[i(y,{type:"text",onClick:r[0]||(r[0]=l=>v.dialogVisible=!0)},{default:d((()=>[b])),_:1}),n((t(),e("div",null,[i(k,{modelValue:v.dialogVisible,"onUpdate:modelValue":r[3]||(r[3]=l=>v.dialogVisible=l),width:"30%"},{title:d((()=>[g])),footer:d((()=>[u("span",m,[i(y,{onClick:r[1]||(r[1]=l=>v.dialogVisible=!1)},{default:d((()=>[p])),_:1}),i(y,{type:"primary",onClick:r[2]||(r[2]=l=>v.dialogVisible=!1)},{default:d((()=>[V])),_:1})])])),default:d((()=>[c])),_:1},8,["modelValue"])])),[[j]])])),_:1})])}]]);export{_ as default};
