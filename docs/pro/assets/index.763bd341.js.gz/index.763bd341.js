
/**
 * 由 Fantastic-admin-discovery 提供技术支持
 * https://hooray.gitee.io/fantastic-admin-discovery/
 * Powered by Fantastic-admin-discovery
 * https://hooray.github.io/fantastic-admin-discovery/
 */
    
import{_ as u}from"./index.1ee8d9f4.js";import{_ as c}from"./plugin-vue_export-helper.5a098b48.js";import{r as d,an as f,I as m,l,j as o,o as g,K as v,J as s,T as a}from"./vendor.6b4522dc.js";const V={data(){return{dialogVisible:!1}}},b=a("\u70B9\u51FB\u6253\u5F00 Dialog"),x=s("div",null," \u6309\u4F4F\u6211\u8FDB\u884C\u62D6\u52A8 ",-1),k=s("span",null,"\u8FD9\u662F\u4E00\u6BB5\u4FE1\u606F",-1),C={class:"dialog-footer"},j=a("\u53D6 \u6D88"),h=a("\u786E \u5B9A");function w(y,e,B,D,t,N){const n=d("el-button"),r=d("el-dialog"),_=u,p=f("drag");return g(),m("div",null,[l(_,null,{default:o(()=>[l(n,{type:"text",onClick:e[0]||(e[0]=i=>t.dialogVisible=!0)},{default:o(()=>[b]),_:1}),v(s("div",null,[l(r,{modelValue:t.dialogVisible,"onUpdate:modelValue":e[3]||(e[3]=i=>t.dialogVisible=i),width:"30%"},{title:o(()=>[x]),footer:o(()=>[s("span",C,[l(n,{onClick:e[1]||(e[1]=i=>t.dialogVisible=!1)},{default:o(()=>[j]),_:1}),l(n,{type:"primary",onClick:e[2]||(e[2]=i=>t.dialogVisible=!1)},{default:o(()=>[h]),_:1})])]),default:o(()=>[k]),_:1},8,["modelValue"])],512),[[p]])]),_:1})])}var I=c(V,[["render",w]]);export{I as default};
