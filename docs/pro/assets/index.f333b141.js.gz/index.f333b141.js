
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a,u as e,g as s}from"./index.9dc02013.js";import{o,k as t,$ as n,Y as r,u as d,s as l,z as p,t as c,x as i,A as u,a1 as m,a2 as f,a3 as g,m as y,C as h}from"./vendor.6ae38f98.js";const _={class:"copyright"},b=["href"],v={key:1},k=n(" All Rights Reserved ");var w=a({setup(a){const s=e();return(a,e)=>(o(),t("footer",_,[n(" Copyright © "+r(d(s).copyright.dates)+" ",1),d(s).copyright.website?(o(),t("a",{key:0,href:d(s).copyright.website,target:"_blank",rel:"noopener"},r(d(s).copyright.company)+",",9,b)):(o(),t("span",v,r(d(s).copyright.company)+",",1)),k]))}},[["__scopeId","data-v-21d46e6a"]]);var x=a({setup(a){const{proxy:_}=h(),b=e(),v=l((()=>s()));function k(a){_.$i18n.locale=a,b.setDefaultLang(a)}return(a,e)=>{const s=p("el-dropdown-item"),l=p("el-dropdown-menu"),h=p("el-dropdown");return d(b).topbar.enableI18n?(o(),c(h,{key:0,class:"language-container",size:"default",onCommand:k},{dropdown:i((()=>[u(l,null,{default:i((()=>[(o(!0),t(f,null,m(d(v),((a,e)=>(o(),c(s,{key:e,disabled:d(b).app.defaultLang===a.name,command:a.name},{default:i((()=>[n(r(a.labelName),1)])),_:2},1032,["disabled","command"])))),128))])),_:1})])),default:i((()=>[g(a.$slots,"default",{},void 0,!0)])),_:3})):y("v-if",!0)}}},[["__scopeId","data-v-898ff48c"]]);export{x as _,w as a};
