
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.e5c277f9.js";import{_ as t}from"./index.c6455cd7.js";import{_ as a}from"./index.e3b25878.js";import{_ as r}from"./index.9dc02013.js";import{k as s,A as l,x as d,z as i,o,$ as n,l as f}from"./vendor.6ae38f98.js";const u={},c=n("返回列表"),m=n("打印"),p=f("div",null,"您提交的内容有如下错误：",-1),_=f("div",null,[n(" 您的账户已被冻结 "),f("a",{href:"###"},"打印")],-1),x=n("返回修改");var y=r(u,[["render",function(r,n){const f=a,u=i("el-button"),y=t,j=e;return o(),s("div",null,[l(f,{title:"处理结果",content:"Result"}),l(j,{title:"成功"},{default:d((()=>[l(y,{type:"success",title:"提交成功",desc:"提交结果页用于反馈一系列操作任务的处理结果。"},{default:d((()=>[l(u,{type:"primary"},{default:d((()=>[c])),_:1}),l(u,null,{default:d((()=>[m])),_:1})])),_:1})])),_:1}),l(j,{title:"失败"},{default:d((()=>[l(y,{type:"error",title:"提交失败",desc:"灰色额外区域可以显示一些补充的信息。请核对并修改以下信息后，再重新提交。"},{extra:d((()=>[p,_])),default:d((()=>[l(u,{type:"primary"},{default:d((()=>[x])),_:1})])),_:1})])),_:1})])}]]);export{y as default};
