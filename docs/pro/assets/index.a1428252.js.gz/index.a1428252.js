
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a}from"./index.ef5f4349.js";import{_ as c}from"./index.da599f69.js";import{_ as i}from"./logo.d77fe55e.js";import{_ as r}from"./index.5c755cb6.js";import{k as l,A as e,x as o,o as d,$ as _,l as n}from"./vendor.18c32348.js";const m={},p=_(" PageMain \u662F\u6700\u5E38\u7528\u7684\u9875\u9762\u7EC4\u4EF6\uFF0C\u51E0\u4E4E\u6240\u6709\u9875\u9762\u90FD\u4F1A\u4F7F\u7528\u5230 "),f=_(" \u8FD9\u91CC\u653E\u9875\u9762\u5185\u5BB9 "),u=n("h1",null,"Fantastic-admin",-1),h=n("img",{src:i},null,-1),x=n("p",null,"\u8FD9\u662F\u4E00\u6B3E\u5F00\u7BB1\u5373\u7528\u7684\u4E2D\u540E\u53F0\u6846\u67B6\uFF0C\u540C\u65F6\u5B83\u4E5F\u7ECF\u5386\u8FC7\u6570\u5341\u4E2A\u771F\u5B9E\u9879\u76EE\u7684\u6280\u672F\u6C89\u6DC0\uFF0C\u786E\u4FDD\u6846\u67B6\u5728\u5F00\u53D1\u4E2D\u53EF\u843D\u5730\u3001\u53EF\u4F7F\u7528\u3001\u53EF\u7EF4\u62A4",-1);function g(j,k){const s=c,t=a;return d(),l("div",null,[e(s,{title:"\u5185\u5BB9\u5757",content:"PageMain"}),e(t,null,{default:o(()=>[p]),_:1}),e(t,{title:"\u4F60\u53EF\u4EE5\u8BBE\u7F6E\u4E00\u4E2A\u81EA\u5B9A\u4E49\u7684\u6807\u9898"},{default:o(()=>[f]),_:1}),e(t,{title:"\u5E26\u5C55\u5F00\u529F\u80FD",collaspe:"",height:"200px"},{default:o(()=>[u,h,x]),_:1})])}var P=r(m,[["render",g]]);export{P as default};
