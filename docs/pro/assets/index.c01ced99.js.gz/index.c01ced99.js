
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.9c1fa942.js";import{bY as n,E as t,c as a,e as s,w as i,n as o,f as u,t as r,h as l,y as m}from"./index.05e4ed9f.js";import{E as d}from"./el-button.a01942a9.js";/* empty css                */import{_ as f}from"./index.dd2c42e8.js";import{_ as c}from"./index.abd93cee.js";import"./index.48c8fc0e.js";import"./index.aa8c6f3e.js";const p=m(" 1 "),b=m(" 1 "),j={setup(m){const j=n();function _(){j.setNumber(j.number+1)}function x(){j.setNumber(j.number-1)}return(n,m)=>{const k=c,v=f,C=t,E=d,N=e;return o(),a("div",null,[s(k,{title:"数字标记",content:"搭配 Pinia 可实现动态设置。请控制数字展示长度，避免导航标记覆盖导航标题，为 0 时则隐藏"}),s(N,null,{default:i((()=>[u("div",null,"当前 badge 值："+r(l(j).number),1),s(E,{onClick:_},{icon:i((()=>[s(C,null,{default:i((()=>[s(v,{name:"ep:plus"})])),_:1})])),default:i((()=>[p])),_:1}),s(E,{onClick:x},{icon:i((()=>[s(C,null,{default:i((()=>[s(v,{name:"ep:minus"})])),_:1})])),default:i((()=>[b])),_:1})])),_:1})])}}};export{j as default};
