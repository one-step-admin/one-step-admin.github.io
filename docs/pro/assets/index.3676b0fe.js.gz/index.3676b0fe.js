
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as t}from"./index.d92f6c0c.js";import{_ as a}from"./index.c2d6d7be.js";import{_ as e}from"./logo.d77fe55e.js";import{_ as l}from"./index.091d1180.js";import{k as n,A as s,x as o,o as i,$ as d,l as r}from"./vendor.b0dde714.js";const f={},m=d(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),u=d(" 这里放页面内容 "),c=r("h1",null,"Fantastic-admin",-1),p=r("img",{src:e},null,-1),_=r("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);var x=l(f,[["render",function(e,l){const d=a,r=t;return i(),n("div",null,[s(d,{title:"内容块",content:"PageMain"}),s(r,null,{default:o((()=>[m])),_:1}),s(r,{title:"你可以设置一个自定义的标题"},{default:o((()=>[u])),_:1}),s(r,{title:"带展开功能",collaspe:"",height:"200px"},{default:o((()=>[c,p,_])),_:1})])}]]);export{x as default};
