
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_}from"./index.836a9402.js";import{_ as r}from"./index.4e4aa5c1.js";import{i as l}from"./index.9d0f40da.js";import{x as m,k as d,A as n,z as o,o as p,l as f,Y as b,u as g,$ as s}from"./vendor.4acdc30d.js";const x=s("1"),h=s("1"),V={setup(k){const e=l();function a(){e.setNumber(e.number+1)}function c(){e.setNumber(e.number-1)}return(B,N)=>{const i=r,t=m("el-button"),u=_;return p(),d("div",null,[n(i,{title:"\u6570\u5B57\u6807\u8BB0",content:"\u642D\u914D Pinia \u53EF\u5B9E\u73B0\u52A8\u6001\u8BBE\u7F6E\u3002\u8BF7\u63A7\u5236\u6570\u5B57\u5C55\u793A\u957F\u5EA6\uFF0C\u907F\u514D\u5BFC\u822A\u6807\u8BB0\u8986\u76D6\u5BFC\u822A\u6807\u9898\uFF0C\u4E3A 0 \u65F6\u5219\u9690\u85CF"}),n(u,null,{default:o(()=>[f("div",null,"\u5F53\u524D badge \u503C\uFF1A"+b(g(e).number),1),n(t,{icon:"el-icon-plus",onClick:a},{default:o(()=>[x]),_:1}),n(t,{icon:"el-icon-minus",onClick:c},{default:o(()=>[h]),_:1})]),_:1})])}}};export{V as default};
