
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.84a18d1d.js";import{_ as l}from"./index.4fc47fa2.js";import{_ as a,c as u,b as d,w as o,m as t,n as s}from"./index.93ad63e3.js";var m=a({data:()=>({value1:null,value2:null,value3:3.7})},[["render",function(a,m,n,r,f,i){const v=l,c=t("el-rate"),V=e;return s(),u("div",null,[d(v),d(V,{title:"基础用法",class:"demo"},{default:o((()=>[d(c,{modelValue:f.value1,"onUpdate:modelValue":m[0]||(m[0]=e=>f.value1=e)},null,8,["modelValue"])])),_:1}),d(V,{title:"辅助文字",class:"demo"},{default:o((()=>[d(c,{modelValue:f.value2,"onUpdate:modelValue":m[1]||(m[1]=e=>f.value2=e),"show-text":"",texts:["极差","差","一般","好","极好"]},null,8,["modelValue"])])),_:1}),d(V,{title:"只读",class:"demo"},{default:o((()=>[d(c,{modelValue:f.value3,"onUpdate:modelValue":m[2]||(m[2]=e=>f.value3=e),disabled:"","show-score":"","text-color":"#ff9900","score-template":"{value}"},null,8,["modelValue"])])),_:1})])}]]);export{m as default};
