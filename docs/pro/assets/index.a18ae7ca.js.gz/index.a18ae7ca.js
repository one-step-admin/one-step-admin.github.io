
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as m}from"./index.ef5f4349.js";import{_ as d}from"./index.da599f69.js";import{u as f}from"./index.5c755cb6.js";import{s as g,k as x,A as e,x as o,z as l,o as b,u as k,af as v,$ as _}from"./vendor.18c32348.js";const V=_("\u5F00\u542F"),h=_("\u5173\u95ED"),N={setup(j){const a=f(),n=g({get:function(){return a.app.enableWatermark},set:function(s){a.$patch(t=>{t.app.enableWatermark=s})}});return(s,t)=>{const u=d,r=l("el-radio-button"),c=l("el-radio-group"),p=m;return b(),x("div",null,[e(u,{title:"\u9875\u9762\u6C34\u5370",content:"\u5728\u67D0\u4E9B\u573A\u666F\u4E0B\uFF0C\u4E0D\u5E0C\u671B\u7528\u6237\u5C06\u7CFB\u7EDF\u91CC\u7684\u4FE1\u606F\u968F\u610F\u622A\u56FE\u5E76\u8F6C\u53D1\uFF0C\u8FD9\u65F6\u53EF\u5F00\u542F\u9875\u9762\u6C34\u5370\uFF0C\u4EE5\u51CF\u5C11\u8FD9\u79CD\u60C5\u51B5\u53D1\u751F"}),e(p,{title:"\u53EF\u5728 src\\layout\\components\\Watermark\\index.vue \u6587\u4EF6\u91CC\u5B9A\u5236\u6C34\u5370\u6587\u6848\u5185\u5BB9"},{default:o(()=>[e(c,{modelValue:k(n),"onUpdate:modelValue":t[0]||(t[0]=i=>v(n)?n.value=i:null)},{default:o(()=>[e(r,{label:!0},{default:o(()=>[V]),_:1}),e(r,{label:!1},{default:o(()=>[h]),_:1})]),_:1},8,["modelValue"])]),_:1})])}}};export{N as default};
