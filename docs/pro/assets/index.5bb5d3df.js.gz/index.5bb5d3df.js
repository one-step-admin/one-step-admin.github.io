
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a}from"./index.84a18d1d.js";import{_ as n}from"./index.621b7b03.js";import{_ as e}from"./index.c51a8d86.js";import{_ as o,c as i,b as d,w as s,m as l,n as t,y as r}from"./index.93ad63e3.js";const m={methods:{open(a){window.open(a,"top")}}},g=r("SVG-Loaders 官网");var c=o(m,[["render",function(o,r,m,c,p,f){const u=l("el-button"),_=e,b=n,v=a;return t(),i("div",null,[d(_,{title:"SVG 动画",content:"svg 文件从 SVG-Loaders 中提取，需要注意，svg 均为白色，需要增加底色才能看到效果。如需封装成加载组件，可参考 SpinkitLoading 组件"},{default:s((()=>[d(u,{icon:"el-icon-link",onClick:r[0]||(r[0]=a=>f.open("http://samherbert.net/svg-loaders/"))},{default:s((()=>[g])),_:1})])),_:1}),d(v,{style:{"background-color":"#34495e"}},{default:s((()=>[d(b,{name:"loading-audio"}),d(b,{name:"loading-ball-triangle"}),d(b,{name:"loading-bars"}),d(b,{name:"loading-circles"}),d(b,{name:"loading-grid"}),d(b,{name:"loading-hearts"}),d(b,{name:"loading-oval"}),d(b,{name:"loading-puff"}),d(b,{name:"loading-rings"}),d(b,{name:"loading-spinning-circles"}),d(b,{name:"loading-tail-spin"}),d(b,{name:"loading-three-dots"})])),_:1})])}],["__scopeId","data-v-3c13ccc0"]]);export{c as default};
