
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as l}from"./index.87525c75.js";import{_ as r}from"./index.a0eee7e3.js";import{_ as c}from"./index.7ad6cc10.js";import{_ as p}from"./index.57e02146.js";import{x as m,k as g,A as e,z as o,o as u,$ as f}from"./vendor.049789a1.js";const v={methods:{open(a){window.open(a,"top")}}},x=f("SVG-Loaders \u5B98\u7F51");function h(a,t,k,b,j,i){const s=m("el-button"),_=c,n=r,d=l;return u(),g("div",null,[e(_,{title:"SVG \u52A8\u753B",content:"svg \u6587\u4EF6\u4ECE SVG-Loaders \u4E2D\u63D0\u53D6\uFF0C\u9700\u8981\u6CE8\u610F\uFF0Csvg \u5747\u4E3A\u767D\u8272\uFF0C\u9700\u8981\u589E\u52A0\u5E95\u8272\u624D\u80FD\u770B\u5230\u6548\u679C\u3002\u5982\u9700\u5C01\u88C5\u6210\u52A0\u8F7D\u7EC4\u4EF6\uFF0C\u53EF\u53C2\u8003 SpinkitLoading \u7EC4\u4EF6"},{default:o(()=>[e(s,{icon:"el-icon-link",onClick:t[0]||(t[0]=V=>i.open("http://samherbert.net/svg-loaders/"))},{default:o(()=>[x]),_:1})]),_:1}),e(d,{style:{"background-color":"#34495e"}},{default:o(()=>[e(n,{name:"loading-audio"}),e(n,{name:"loading-ball-triangle"}),e(n,{name:"loading-bars"}),e(n,{name:"loading-circles"}),e(n,{name:"loading-grid"}),e(n,{name:"loading-hearts"}),e(n,{name:"loading-oval"}),e(n,{name:"loading-puff"}),e(n,{name:"loading-rings"}),e(n,{name:"loading-spinning-circles"}),e(n,{name:"loading-tail-spin"}),e(n,{name:"loading-three-dots"})]),_:1})])}var G=p(v,[["render",h],["__scopeId","data-v-3c13ccc0"]]);export{G as default};
