
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as i,u,g as C}from"./index.9d0f40da.js";import{o,k as s,$ as c,Y as r,u as e,t as k,x as l,y as m,z as _,A as w,a1 as b,a2 as S,a3 as $,m as I,C as L}from"./vendor.4acdc30d.js";const N={class:"copyright"},B=["href"],D={key:1},V=c(" All Rights Reserved "),j={setup(g){const t=u();return(n,p)=>(o(),s("footer",N,[c(" Copyright \xA9 "+r(e(t).copyrightDates)+" ",1),e(t).copyrightWebsite?(o(),s("a",{key:0,href:e(t).copyrightWebsite,target:"_blank",rel:"noopener"},r(e(t).copyrightCompany)+",",9,B)):(o(),s("span",D,r(e(t).copyrightCompany)+",",1)),V]))}};var W=i(j,[["__scopeId","data-v-439d53fe"]]);const z={setup(g){const{proxy:t}=L(),n=u(),p=k(()=>C());function f(a){t.$i18n.locale=a,n.setDefaultLang(a)}return(a,A)=>{const y=l("el-dropdown-item"),h=l("el-dropdown-menu"),v=l("el-dropdown");return e(n).enableI18n?(o(),m(v,{key:0,class:"language-container",size:"medium",onCommand:f},{dropdown:_(()=>[w(h,null,{default:_(()=>[(o(!0),s(S,null,b(e(p),(d,x)=>(o(),m(y,{key:x,disabled:e(n).defaultLang===d.name,command:d.name},{default:_(()=>[c(r(d.labelName),1)]),_:2},1032,["disabled","command"]))),128))]),_:1})]),default:_(()=>[$(a.$slots,"default",{},void 0,!0)]),_:3})):I("v-if",!0)}}};var F=i(z,[["__scopeId","data-v-d539cd02"]]);export{F as _,W as a};
