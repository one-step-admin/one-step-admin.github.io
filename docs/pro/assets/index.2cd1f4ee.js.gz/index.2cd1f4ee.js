
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a}from"./index.e5c277f9.js";import{_ as e}from"./index.e3b25878.js";import{_ as t}from"./logo.d77fe55e.js";import{_ as l}from"./index.9dc02013.js";import{k as n,A as s,x as o,o as i,$ as r,l as d}from"./vendor.6ae38f98.js";const f={},m=r(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),u=r(" 这里放页面内容 "),c=d("h1",null,"Fantastic-admin",-1),p=d("img",{src:t},null,-1),_=d("p",null,"这是一款开箱即用的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护",-1);var x=l(f,[["render",function(t,l){const r=e,d=a;return i(),n("div",null,[s(r,{title:"内容块",content:"PageMain"}),s(d,null,{default:o((()=>[m])),_:1}),s(d,{title:"你可以设置一个自定义的标题"},{default:o((()=>[u])),_:1}),s(d,{title:"带展开功能",collaspe:"",height:"200px"},{default:o((()=>[c,p,_])),_:1})])}]]);export{x as default};
