
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a}from"./index.8346cdbe.js";import{_ as n}from"./index.4f74a808.js";import{_ as e}from"./index.8b7064ca.js";import{_ as o,c as i,b as d,w as s,m as l,n as t,y as r}from"./index.d26282ba.js";const m={methods:{open(a){window.open(a,"top")}}},c=r("SVG-Loaders 官网");var g=o(m,[["render",function(o,r,m,g,p,f){const u=l("el-button"),b=e,_=n,v=a;return t(),i("div",null,[d(b,{title:"SVG 动画",content:"svg 文件从 SVG-Loaders 中提取，需要注意，svg 均为白色，需要增加底色才能看到效果。如需封装成加载组件，可参考 SpinkitLoading 组件"},{default:s((()=>[d(u,{icon:"el-icon-link",onClick:r[0]||(r[0]=a=>f.open("http://samherbert.net/svg-loaders/"))},{default:s((()=>[c])),_:1})])),_:1}),d(v,{style:{"background-color":"#34495e"}},{default:s((()=>[d(_,{name:"loading-audio"}),d(_,{name:"loading-ball-triangle"}),d(_,{name:"loading-bars"}),d(_,{name:"loading-circles"}),d(_,{name:"loading-grid"}),d(_,{name:"loading-hearts"}),d(_,{name:"loading-oval"}),d(_,{name:"loading-puff"}),d(_,{name:"loading-rings"}),d(_,{name:"loading-spinning-circles"}),d(_,{name:"loading-tail-spin"}),d(_,{name:"loading-three-dots"})])),_:1})])}],["__scopeId","data-v-3c13ccc0"]]);export{g as default};
