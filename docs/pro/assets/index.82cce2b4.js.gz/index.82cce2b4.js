
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.e4264495.js";import{bY as n,E as t,c as s,g as i,w as a,o,a as u,t as r,i as l,y as m}from"./index.b046d3e8.js";import{E as f}from"./el-button.12f8eb95.js";/* empty css                */import{_ as d}from"./index.f1e68254.js";import{_ as b}from"./index.f15ab100.js";import"./index.2b0c4341.js";import"./index.16ef6f7e.js";const c=m(" 1 "),p=m(" 1 "),j={setup(m){const j=n();function _(){j.setNumber(j.number+1)}function x(){j.setNumber(j.number-1)}return(n,m)=>{const g=b,k=d,v=t,C=f,E=e;return o(),s("div",null,[i(g,{title:"数字标记",content:"搭配 Pinia 可实现动态设置。请控制数字展示长度，避免导航标记覆盖导航标题，为 0 时则隐藏"}),i(E,null,{default:a((()=>[u("div",null,"当前 badge 值："+r(l(j).number),1),i(C,{onClick:_},{icon:a((()=>[i(v,null,{default:a((()=>[i(k,{name:"ep:plus"})])),_:1})])),default:a((()=>[c])),_:1}),i(C,{onClick:x},{icon:a((()=>[i(v,null,{default:a((()=>[i(k,{name:"ep:minus"})])),_:1})])),default:a((()=>[p])),_:1})])),_:1})])}}};export{j as default};
