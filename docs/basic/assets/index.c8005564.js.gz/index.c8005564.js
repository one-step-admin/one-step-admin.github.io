
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.f6f9a61b.js";import{_ as l}from"./index.2283cd0c.js";import{_ as a}from"./plugin-vue_export-helper.21dcd24c.js";import{C as o,f as u,e as d,r as t,o as m}from"./vendor.2ae12b47.js";var s=a({data:()=>({value:!0,value1:!0,value2:!0,value3:!1})},[["render",function(a,s,i,r,n,v){const c=l,f=t("el-switch"),p=e;return m(),o("div",null,[u(c),u(p,{title:"基础用法",class:"demo"},{default:d((()=>[u(f,{modelValue:n.value,"onUpdate:modelValue":s[0]||(s[0]=e=>n.value=e),"active-color":"#13ce66","inactive-color":"#ff4949"},null,8,["modelValue"])])),_:1}),u(p,{title:"文字描述",class:"demo"},{default:d((()=>[u(f,{modelValue:n.value1,"onUpdate:modelValue":s[1]||(s[1]=e=>n.value1=e),"active-text":"按月付费","inactive-text":"按年付费"},null,8,["modelValue"])])),_:1}),u(p,{title:"禁用状态",class:"demo"},{default:d((()=>[u(f,{modelValue:n.value2,"onUpdate:modelValue":s[2]||(s[2]=e=>n.value2=e),disabled:"",style:{"margin-right":"10px"}},null,8,["modelValue"]),u(f,{modelValue:n.value3,"onUpdate:modelValue":s[3]||(s[3]=e=>n.value3=e),disabled:""},null,8,["modelValue"])])),_:1})])}]]);export{s as default};
