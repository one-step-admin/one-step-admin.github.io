
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.d3415f46.js";import{_ as t}from"./index.dc0a326f.js";import{_ as a}from"./logo.d77fe55e.js";import{_ as l}from"./plugin-vue_export-helper.21dcd24c.js";import{C as n,f as o,e as s,o as r,P as i,D as d}from"./vendor.2ae12b47.js";const f={},p=i(" PageMain 是最常用的页面组件，几乎所有页面都会使用到 "),u=i(" 这里放页面内容 "),m=d("h1",null,"One-step-admin",-1),c=d("img",{src:a},null,-1),_=d("p",null,"这是一款干啥都快人一步的中后台框架，它拥有全新的交互方式，只为提升操作效率而生。",-1);var g=l(f,[["render",function(a,l){const i=t,d=e;return r(),n("div",null,[o(i,{title:"内容块",content:"PageMain"}),o(d,null,{default:s((()=>[p])),_:1}),o(d,{title:"你可以设置一个自定义的标题"},{default:s((()=>[u])),_:1}),o(d,{title:"带展开功能",collaspe:"",height:"200px"},{default:s((()=>[m,c,_])),_:1})])}]]);export{g as default};
