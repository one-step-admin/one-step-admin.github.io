
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as e}from"./index.64b0a20f.js";import{_ as l}from"./index.d7d40d83.js";import{_ as a}from"./plugin-vue_export-helper.21dcd24c.js";import{c as d,e as o,f as u,m as t,n as s}from"./index.8b6d4e84.js";var m=a({data:()=>({value1:null,value2:null,value3:3.7})},[["render",function(a,m,r,n,i,f){const v=l,p=t("el-rate"),c=e;return s(),d("div",null,[o(v),o(c,{title:"基础用法",class:"demo"},{default:u((()=>[o(p,{modelValue:i.value1,"onUpdate:modelValue":m[0]||(m[0]=e=>i.value1=e)},null,8,["modelValue"])])),_:1}),o(c,{title:"辅助文字",class:"demo"},{default:u((()=>[o(p,{modelValue:i.value2,"onUpdate:modelValue":m[1]||(m[1]=e=>i.value2=e),"show-text":"",texts:["极差","差","一般","好","极好"]},null,8,["modelValue"])])),_:1}),o(c,{title:"只读",class:"demo"},{default:u((()=>[o(p,{modelValue:i.value3,"onUpdate:modelValue":m[2]||(m[2]=e=>i.value3=e),disabled:"","show-score":"","text-color":"#ff9900","score-template":"{value}"},null,8,["modelValue"])])),_:1})])}]]);export{m as default};
