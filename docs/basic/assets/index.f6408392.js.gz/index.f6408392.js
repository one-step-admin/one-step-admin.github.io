
/**
 * 由 One-step-admin 提供技术支持
 * https://hooray.gitee.io/one-step-admin/
 * Powered by One-step-admin
 * https://hooray.github.io/one-step-admin/
 */
    
import{_ as a}from"./index.e449b433.js";import{_ as c}from"./index.703d4ac1.js";import{_ as i}from"./logo.d77fe55e.js";import{_ as r}from"./plugin-vue_export-helper.21dcd24c.js";import{F as l,f as e,e as o,o as d,P as _,G as n}from"./vendor.65690658.js";const p={},m=_(" PageMain \u662F\u6700\u5E38\u7528\u7684\u9875\u9762\u7EC4\u4EF6\uFF0C\u51E0\u4E4E\u6240\u6709\u9875\u9762\u90FD\u4F1A\u4F7F\u7528\u5230 "),u=_(" \u8FD9\u91CC\u653E\u9875\u9762\u5185\u5BB9 "),f=n("h1",null,"One-step-admin",-1),h=n("img",{src:i},null,-1),g=n("p",null,"\u8FD9\u662F\u4E00\u6B3E\u5E72\u5565\u90FD\u5FEB\u4EBA\u4E00\u6B65\u7684\u4E2D\u540E\u53F0\u6846\u67B6\uFF0C\u5B83\u62E5\u6709\u5168\u65B0\u7684\u4EA4\u4E92\u65B9\u5F0F\uFF0C\u53EA\u4E3A\u63D0\u5347\u64CD\u4F5C\u6548\u7387\u800C\u751F\u3002",-1);function x(j,v){const s=c,t=a;return d(),l("div",null,[e(s,{title:"\u5185\u5BB9\u5757",content:"PageMain"}),e(t,null,{default:o(()=>[m]),_:1}),e(t,{title:"\u4F60\u53EF\u4EE5\u8BBE\u7F6E\u4E00\u4E2A\u81EA\u5B9A\u4E49\u7684\u6807\u9898"},{default:o(()=>[u]),_:1}),e(t,{title:"\u5E26\u5C55\u5F00\u529F\u80FD",collaspe:"",height:"200px"},{default:o(()=>[f,h,g]),_:1})])}var M=r(p,[["render",x]]);export{M as default};
